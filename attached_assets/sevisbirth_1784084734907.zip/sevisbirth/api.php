<?php
/* ============================================================
   FILE: api.php
   Main API Router — handles all /api/* requests

   Routes (via ?route= parameter):
     GET    birth-records          — List records (filtered by role)
     POST   birth-records          — Create new record
     GET    birth-records/{id}     — Get single record with history
     POST   birth-records/{id}/transitions — Execute state transition
     GET    stats                  — Dashboard statistics
   ============================================================ */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/database.php';
require_once __DIR__ . '/includes/middleware.php';
require_once __DIR__ . '/includes/state-machine.php';
require_once __DIR__ . '/includes/requirements.php';
require_once __DIR__ . '/includes/validation.php';

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization');
    exit;
}

$route = $_GET['route'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true) ?? [];

try {
    $user = Middleware::requireAuth();

    if ($route === 'birth-records' && $method === 'GET') {
        handleListRecords($user);
    }
    elseif ($route === 'birth-records' && $method === 'POST') {
        handleCreateRecord($user, $input);
    }
    elseif (preg_match('#^birth-records/([A-Za-z0-9\-]+)$#', $route, $m) && $method === 'GET') {
        handleGetRecord($user, $m[1]);
    }
    elseif (preg_match('#^birth-records/([A-Za-z0-9\-]+)/transitions$#', $route, $m) && $method === 'POST') {
        handleTransition($user, $m[1], $input);
    }
    elseif ($route === 'stats' && $method === 'GET') {
        handleStats($user);
    }
    else {
        Middleware::jsonResponse(['success' => false, 'error' => "Route not found: {$route}"], 404);
    }

} catch (Exception $e) {
    Middleware::jsonResponse(['success' => false, 'error' => $e->getMessage()], 500);
}

function handleListRecords(array $user): void {
    $db = Database::getInstance();
    $params = [];
    $where = [];
    $limit = min((int)($_GET['limit'] ?? 50), 100);
    $offset = ((int)($_GET['page'] ?? 1) - 1) * $limit;

    if ($user['role'] === 'field_worker') {
        $where[] = "operator_name = ?";
        $params[] = $user['name'];
    }

    if ($user['role'] === 'civil_registrar') {
        $state = $_GET['state'] ?? '';
        if ($state && StateMachine::isValidState($state)) {
            $where[] = "state = ?";
            $params[] = $state;
        }
    }

    $whereClause = $where ? 'WHERE ' . implode(' AND ', $where) : '';

    $countStmt = $db->prepare("SELECT COUNT(*) as total FROM birth_records {$whereClause}");
    $countStmt->execute($params);
    $total = $countStmt->fetch()['total'];

    $sql = "SELECT id, state, child_data, birth_event, operator_name, operator_role, facility_code, created_at, updated_at, version FROM birth_records {$whereClause} ORDER BY created_at DESC LIMIT ? OFFSET ?";
    $params[] = $limit;
    $params[] = $offset;
    $stmt = $db->prepare($sql);
    $stmt->execute($params);

    $records = [];
    while ($row = $stmt->fetch()) {
        $child = json_decode($row['child_data'], true) ?? [];
        $be = json_decode($row['birth_event'], true) ?? [];
        $records[] = [
            'id' => $row['id'],
            'state' => $row['state'],
            'stateLabel' => StateMachine::STATE_LABELS[$row['state']] ?? $row['state'],
            'child' => [
                'firstName' => $child['firstName'] ?? '',
                'lastName' => $child['lastName'] ?? '',
                'sex' => $child['sex'] ?? '',
                'dateOfBirth' => $be['dateOfBirth'] ?? '',
                'birthWeight' => $child['birthWeight'] ?? null
            ],
            'birthEvent' => [
                'type' => $be['type'] ?? '',
                'notifierTier' => $be['notifierTier'] ?? 0,
                'facilityName' => $be['facilityName'] ?? '',
                'village' => $be['village'] ?? ''
            ],
            'notification' => [
                'officerName' => $row['operator_name'],
                'facilityCode' => $row['facility_code']
            ],
            'createdAt' => $row['created_at'],
            'updatedAt' => $row['updated_at'],
            'version' => $row['version']
        ];
    }

    Middleware::jsonResponse([
        'success' => true,
        'records' => $records,
        'pagination' => [
            'total' => (int) $total,
            'page' => (int)($_GET['page'] ?? 1),
            'limit' => $limit,
            'pages' => (int) ceil($total / $limit)
        ]
    ]);
}

function handleCreateRecord(array $user, array $input): void {
    Middleware::requireRole($user, ['field_worker']);

    $structCheck = Validation::validateRecordPayload($input);
    if (!$structCheck['valid']) {
        Middleware::jsonResponse(['success' => false, 'error' => 'Validation failed', 'details' => $structCheck['errors']], 400);
        return;
    }

    $reqCheck = Requirements::validateForSubmission($input);
    if (!$reqCheck['valid']) {
        Middleware::jsonResponse(['success' => false, 'error' => 'Requirements not met', 'details' => $reqCheck['errors'], 'warnings' => $reqCheck['warnings'], 'flags' => $reqCheck['flags']], 400);
        return;
    }

    $db = Database::getInstance();
    $now = gmdate('Y-m-d\TH:i:s\Z');
    $id = 'BR-' . date('Y') . '-' . str_pad($db->query("SELECT COUNT(*) FROM birth_records")->fetchColumn() + 1, 5, '0', STR_PAD_LEFT);

    $dupCheck = $db->prepare("SELECT id FROM birth_records WHERE id = ?");
    $dupCheck->execute([$id]);
    if ($dupCheck->fetch()) {
        $id = 'BR-' . date('Y') . '-' . str_pad(rand(10000, 99999), 5, '0', STR_PAD_LEFT);
    }

    $encryptionMeta = Database::encrypt($input);
    $plaintextHash = Database::hashData($input);

    $stmt = $db->prepare("
        INSERT INTO birth_records (id, state, birth_event, child_data, mother_data, father_data, witnesses_data, evidence_data, encrypted_blob, encryption_meta, plaintext_hash, operator_did, operator_name, operator_role, facility_code, created_at, updated_at)
        VALUES (?, 'submitted', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([
        $id,
        json_encode($input['birthEvent'] ?? [], JSON_UNESCAPED_UNICODE),
        json_encode($input['child'] ?? [], JSON_UNESCAPED_UNICODE),
        json_encode($input['mother'] ?? [], JSON_UNESCAPED_UNICODE),
        json_encode($input['father'] ?? [], JSON_UNESCAPED_UNICODE),
        json_encode($input['witnesses'] ?? [], JSON_UNESCAPED_UNICODE),
        json_encode($input['evidence'] ?? [], JSON_UNESCAPED_UNICODE),
        $encryptionMeta['ciphertext'],
        json_encode($encryptionMeta, JSON_UNESCAPED_UNICODE),
        $plaintextHash,
        $user['sub'] ?? '',
        $user['name'],
        $user['role'],
        $user['facilityCode'] ?? '',
        $now,
        $now
    ]);

    $histStmt = $db->prepare("INSERT INTO state_history (record_id, from_state, to_state, actor_name, actor_role, reason, created_at) VALUES (?, NULL, 'submitted', ?, ?, '', ?)");
    $histStmt->execute([$id, $user['name'], $user['role'], $now]);

    StateMachine::autoAdvance($db, $id);

    $finalStmt = $db->prepare("SELECT state FROM birth_records WHERE id = ?");
    $finalStmt->execute([$id]);
    $finalState = $finalStmt->fetchColumn();

    Middleware::jsonResponse([
        'success' => true,
        'id' => $id,
        'state' => $finalState,
        'createdAt' => $now,
        'warnings' => $reqCheck['warnings'],
        'flags' => $reqCheck['flags']
    ], 201);
}

function handleGetRecord(array $user, string $id): void {
    $db = Database::getInstance();
    $stmt = $db->prepare("SELECT * FROM birth_records WHERE id = ?");
    $stmt->execute([$id]);
    $row = $stmt->fetch();

    if (!$row) {
        Middleware::jsonResponse(['success' => false, 'error' => 'Record not found'], 404);
        return;
    }

    if ($user['role'] === 'field_worker' && $row['operator_name'] !== $user['name']) {
        Middleware::jsonResponse(['success' => false, 'error' => 'Access denied'], 403);
        return;
    }

    $histStmt = $db->prepare("SELECT * FROM state_history WHERE record_id = ? ORDER BY created_at ASC");
    $histStmt->execute([$id]);
    $history = $histStmt->fetchAll();

    $meta = json_decode($row['encryption_meta'], true) ?? [];
    $decrypted = Database::decrypt($meta, $row['encrypted_blob']);
    $data = $decrypted ?? [
        'birthEvent' => json_decode($row['birth_event'], true) ?? [],
        'child' => json_decode($row['child_data'], true) ?? [],
        'mother' => json_decode($row['mother_data'], true) ?? [],
        'father' => json_decode($row['father_data'], true) ?? [],
        'witnesses' => json_decode($row['witnesses_data'], true) ?? [],
        'evidence' => json_decode($row['evidence_data'], true) ?? []
    ];

    $be = $data['birthEvent'] ?? [];
    $timing = Requirements::calcTiming($be['dateOfBirth'] ?? null);
    $witnessReqs = Requirements::getWitnessRequirements($be['type'] ?? '', $be['notifierTier'] ?? 2);
    $evidenceReqs = Requirements::getEvidenceRequirements($be['type'] ?? '', $timing['category'] ?? null);
    $witnessCheck = Requirements::checkWitnesses($witnessReqs, $data['witnesses'] ?? []);
    $evidenceCheck = Requirements::checkEvidence($evidenceReqs, $data['evidence'] ?? []);
    $flags = Requirements::generateFlags($data);

    Middleware::jsonResponse([
        'success' => true,
        'record' => [
            'id' => $row['id'],
            'state' => $row['state'],
            'stateLabel' => StateMachine::STATE_LABELS[$row['state']] ?? $row['state'],
            'data' => $data,
            'notification' => [
                'officerName' => $row['operator_name'],
                'officerRole' => $row['operator_role'],
                'facilityCode' => $row['facility_code']
            ],
            'requirements' => [
                'witnesses' => ['required' => $witnessReqs, 'met' => $witnessCheck['met']],
                'evidence' => ['required' => $evidenceReqs, 'met' => $evidenceCheck['met'], 'missing' => $evidenceCheck['missing']],
                'timing' => $timing
            ],
            'flags' => $flags,
            'history' => $history,
            'createdAt' => $row['created_at'],
            'updatedAt' => $row['updated_at'],
            'version' => $row['version'],
            'encrypted' => !empty($row['encrypted_blob'])
        ]
    ]);
}

function handleTransition(array $user, string $id, array $input): void {
    $transition = $input['transition'] ?? '';
    $reason = $input['reason'] ?? '';

    if (empty($transition)) {
        Middleware::jsonResponse(['success' => false, 'error' => 'Missing transition parameter'], 400);
        return;
    }

    $stateMap = [
        'submit' => 'submitted',
        'approve' => 'approved',
        'reject' => 'rejected',
        'resubmit' => 'submitted',
        'retry' => 'submitted',
        'void' => 'voided'
    ];

    $targetState = $stateMap[$transition] ?? null;
    if (!$targetState) {
        Middleware::jsonResponse(['success' => false, 'error' => "Unknown transition: {$transition}"], 400);
        return;
    }

    if (in_array($transition, ['approve', 'reject'])) {
        Middleware::requireRole($user, ['civil_registrar']);
    }
    if (in_array($transition, ['submit', 'resubmit', 'retry'])) {
        Middleware::requireRole($user, ['field_worker']);
    }
    if ($transition === 'void') {
        Middleware::requireRole($user, ['registrar_general']);
    }

    $db = Database::getInstance();
    $result = StateMachine::executeTransition($db, $id, $targetState, $user['name'], $user['role'], $reason);

    if (!$result['success']) {
        $code = str_contains($result['error'], 'not found') ? 404 : 409;
        Middleware::jsonResponse(['success' => false, 'error' => $result['error']], $code);
        return;
    }

    StateMachine::autoAdvance($db, $id);

    $finalStmt = $db->prepare("SELECT state FROM birth_records WHERE id = ?");
    $finalStmt->execute([$id]);
    $finalState = $finalStmt->fetchColumn();

    Middleware::jsonResponse([
        'success' => true,
        'id' => $id,
        'previousState' => $result['previousState'],
        'newState' => $finalState,
        'transitionedBy' => ['name' => $user['name'], 'role' => $user['role']],
        'timestamp' => gmdate('Y-m-d\TH:i:s\Z')
    ]);
}

function handleStats(array $user): void {
    $db = Database::getInstance();

    $where = $user['role'] === 'field_worker' ? "WHERE operator_name = ?" : "";
    $params = $user['role'] === 'field_worker' ? [$user['name']] : [];

    $sql = "SELECT state, COUNT(*) as count FROM birth_records {$where} GROUP BY state";
    $stmt = $db->prepare($sql);
    $stmt->execute($params);

    $byState = [];
    while ($row = $stmt->fetch()) {
        $byState[$row['state']] = (int) $row['count'];
    }

    $total = array_sum($byState);

    Middleware::jsonResponse([
        'success' => true,
        'stats' => [
            'total' => $total,
            'byState' => $byState,
            'pending' => ($byState['submitted'] ?? 0) + ($byState['failed'] ?? 0),
            'inReview' => ($byState['reviewing'] ?? 0) + ($byState['received'] ?? 0),
            'completed' => $byState['complete'] ?? 0
        ]
    ]);
}
