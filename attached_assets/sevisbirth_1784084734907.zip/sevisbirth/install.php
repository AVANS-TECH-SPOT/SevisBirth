<?php
/* ============================================================
   FILE: install.php
   One-Click Database Installer
   Run once after deploying files. Creates SQLite DB + seeds data.
   ============================================================ */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/database.php';

$messages = [];
$success = true;

try {
    if (!extension_loaded('pdo_sqlite')) {
        throw new RuntimeException('PDO SQLite extension is not loaded. Please enable it in php.ini.');
    }

    if (!extension_loaded('openssl')) {
        throw new RuntimeException('OpenSSL extension is not loaded. Required for AES-256-GCM encryption.');
    }

    if (!is_dir(DB_DIR)) {
        if (!mkdir(DB_DIR, 0755, true)) {
            throw new RuntimeException("Cannot create data directory: " . DB_DIR);
        }
        $messages[] = "Created directory: " . DB_DIR;
    }

    if (!is_writable(DB_DIR)) {
        throw new RuntimeException("Data directory is not writable: " . DB_DIR);
    }

    // If database exists but is corrupted/empty, remove it and recreate
    $dbExists = file_exists(DB_PATH);
    if ($dbExists) {
        try {
            $testDb = new PDO('sqlite:' . DB_PATH);
            $testDb->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $userCount = $testDb->query("SELECT COUNT(*) FROM mock_users")->fetchColumn();
            if ($userCount == 0) {
                // Empty database, remove and recreate
                unset($testDb);
                unlink(DB_PATH);
                $messages[] = "Removed empty database, recreating...";
                $dbExists = false;
            }
        } catch (Exception $e) {
            // Corrupted or schema mismatch, remove it
            unset($testDb);
            @unlink(DB_PATH);
            $messages[] = "Removed corrupted database, recreating...";
            $dbExists = false;
        }
    }

    Database::initSchema();
    $messages[] = "Database schema created/verified: " . DB_PATH;

    Database::seedMockUsers();
    $messages[] = "Mock users seeded (5 users across 4 tiers)";

    $db = Database::getInstance();
    $tables = $db->query("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")->fetchAll(PDO::FETCH_COLUMN);
    $messages[] = "Tables created: " . implode(', ', $tables);

    $userCount = $db->query("SELECT COUNT(*) FROM mock_users")->fetchColumn();
    $messages[] = "Mock users in database: {$userCount}";

    $htaccess = DB_DIR . '/.htaccess';
    if (!file_exists($htaccess)) {
        file_put_contents($htaccess, "Deny from all\n");
        $messages[] = "Created .htaccess to protect data directory";
    }

} catch (Exception $e) {
    $success = false;
    $messages[] = "ERROR: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SevisBirth — Installer</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: 'Plus Jakarta Sans', system-ui, sans-serif;
            background: #0B1D15;
            color: #E4EDE8;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .card {
            background: #1A3729;
            border: 1px solid #245038;
            border-radius: 16px;
            padding: 40px;
            max-width: 560px;
            width: 90%;
        }
        h1 {
            font-size: 28px;
            font-weight: 800;
            margin-bottom: 8px;
            color: #E5B340;
            font-family: 'Plus Jakarta Sans', sans-serif;
        }
        .sub { color: #8BAA98; font-size: 14px; margin-bottom: 24px; }
        .msg {
            padding: 10px 14px;
            border-radius: 8px;
            font-size: 13px;
            margin-bottom: 8px;
            font-family: 'JetBrains Mono', monospace;
        }
        .msg.ok { background: #064E3B; color: #6EE7B7; }
        .msg.err { background: #7F1D1D; color: #FCA5A5; }
        .badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 999px;
            font-size: 12px;
            font-weight: 700;
            margin-bottom: 20px;
        }
        .badge.ok { background: #065F46; color: #6EE7B7; }
        .badge.err { background: #7F1D1D; color: #FCA5A5; }
        a.btn {
            display: inline-block;
            margin-top: 20px;
            padding: 12px 28px;
            background: #C9962A;
            color: #0B1D15;
            border-radius: 8px;
            font-weight: 700;
            text-decoration: none;
            font-size: 15px;
            font-family: 'Plus Jakarta Sans', sans-serif;
        }
        a.btn:hover { background: #E5B340; }
        .info {
            margin-top: 20px;
            padding: 14px;
            background: #132B20;
            border-radius: 8px;
            font-size: 12px;
            color: #8BAA98;
            font-family: 'JetBrains Mono', monospace;
        }
        .info strong { color: #E4EDE8; }
        .users-list {
            margin-top: 12px;
            padding: 14px;
            background: #0B1D15;
            border-radius: 8px;
            font-size: 12px;
            color: #8BAA98;
            font-family: 'JetBrains Mono', monospace;
        }
    </style>
</head>
<body>
<div class="card">
    <h1>SevisBirth Installer</h1>
    <p class="sub">Database setup and configuration verification</p>

    <span class="badge <?php echo $success ? 'ok' : 'err'; ?>">
        <?php echo $success ? 'INSTALLATION SUCCESSFUL' : 'INSTALLATION FAILED'; ?>
    </span>

    <?php foreach ($messages as $m): ?>
        <div class="msg <?php echo $success ? 'ok' : 'err'; ?>"><?php echo htmlspecialchars($m); ?></div>
    <?php endforeach; ?>

    <?php if ($success): ?>
        <a class="btn" href="index.php">Launch SevisBirth</a>

        <div class="info">
            <strong>SevisPass Bypass Mode:</strong> <?php echo SEVISPASS_BYPASS ? 'ENABLED' : 'DISABLED'; ?><br>
            <strong>Database:</strong> <?php echo DB_PATH; ?><br>
            <strong>Environment:</strong> <?php echo APP_ENV; ?><br>
            <strong>Encryption:</strong> AES-256-GCM (PBKDF2 <?php echo PBKDF2_ITERATIONS; ?> iterations)
        </div>

        <div class="users-list">
            <strong>Mock Users:</strong><br>
            <?php
            $users = $db->query("SELECT name, role, tier, facility_name, sevispass_id FROM mock_users ORDER BY tier")->fetchAll();
            foreach ($users as $u) {
                $tierLabel = ['VHV','CHW','NO','MO','SP'][$u['tier']] ?? '?';
                echo "• T{$u['tier']} {$tierLabel} — {$u['name']} — {$u['role']} ({$u['facility_name']}) — ID: {$u['sevispass_id']}<br>";
            }
            ?>
        </div>
    <?php endif; ?>
</div>
</body>
</html>
