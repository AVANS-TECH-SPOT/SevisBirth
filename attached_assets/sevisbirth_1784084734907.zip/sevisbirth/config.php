<?php
/* ============================================================
   FILE: config.php
   SevisBirth Application Configuration
   PNG Digital Birth Registration System
   ============================================================ */

define('APP_NAME', 'SevisBirth');
define('APP_VERSION', '2.0.0');
define('APP_ENV', 'development');

// Database
$baseDir = __DIR__;
define('DB_PATH', $baseDir . '/data/sevisbirth.db');
define('DB_DIR', $baseDir . '/data');

// SevisPass Mock SSO
// Set to TRUE to bypass real wallet authentication
define('SEVISPASS_BYPASS', true);
define('SEVISPASS_SERVER_URL', 'http://localhost/mock_sevispass.php');
define('SEVISPASS_CLIENT_ID', 'sevisbirth-png-dev');
define('SEVISPASS_CLIENT_SECRET', 'dev-secret-do-not-use-in-prod');

// Session
define('SESSION_LIFETIME_HOURS', 8);
define('POLL_INTERVAL_MS', 2000);
define('MAX_POLL_SECONDS', 300);

// Encryption — server-side for prototype (client-side in production)
define('ENCRYPTION_PASSPHRASE', 'sevisbirth-prototype-key-change-in-prod');
define('PBKDF2_ITERATIONS', 100000);

// PNG Civil Registration Act 2024 thresholds (days)
define('LATE_REGISTRATION_DAYS', 90);     // ~3 months
define('VERY_LATE_REGISTRATION_DAYS', 365); // 1 year

// PNG Provinces
define('PNG_PROVINCES', [
    'National Capital District',
    'Central', 'Chimbu', 'Eastern Highlands', 'East New Britain',
    'East Sepik', 'Enga', 'Gulf', 'Hela', 'Jiwaka', 'Madang',
    'Manus', 'Milne Bay', 'Morobe', 'New Ireland', 'Northern (Oro)',
    'Bougainville', 'Southern Highlands', 'Western', 'West New Britain',
    'West Sepik (Sandaun)', 'Western Highlands'
]);

// CORS
define('ALLOWED_ORIGINS', ['http://localhost', 'http://127.0.0.1']);

// Error reporting
if (APP_ENV === 'development') {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
} else {
    error_reporting(0);
    ini_set('display_errors', '0');
}
