<?php
require_once __DIR__ . '/requirements.php';

/* ============================================================
   FILE: includes/validation.php
   Input Validation Utilities
   ============================================================ */

class Validation {

    public static function validateBirthEventType(string $type): bool {
        return in_array($type, Requirements::BIRTH_TYPES, true);
    }

    public static function validateSex(string $sex): bool {
        return in_array($sex, ['male', 'female', 'intersex'], true);
    }

    public static function validateMaritalStatus(string $status): bool {
        return in_array($status, ['single', 'married', 'divorced', 'widowed'], true);
    }

    public static function validateEducation(string $edu): bool {
        return in_array($edu, ['none', 'primary', 'secondary', 'tertiary'], true);
    }

    public static function validateTier(int $tier): bool {
        return $tier >= 0 && $tier <= 4;
    }

    public static function validateDate(string $date): bool {
        if (empty($date)) return false;
        $d = DateTime::createFromFormat('Y-m-d', $date);
        return $d && $d->format('Y-m-d') === $date;
    }

    public static function validateUUID(string $id): bool {
        return preg_match('/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i', $id) === 1
            || preg_match('/^BR-\d{4}-\d{5}$/', $id) === 1;
    }

    public static function validateFatherUnavailableReason(string $reason): bool {
        return in_array($reason, ['unknown', 'deceased', 'abandoned', 'refused', 'other'], true);
    }

    public static function sanitizeString(string $input): string {
        return trim(htmlspecialchars($input, ENT_QUOTES | ENT_HTML5, 'UTF-8'));
    }

    public static function validateRecordPayload(array $payload): array {
        $errors = [];

        if (empty($payload['birthEvent']) || !is_array($payload['birthEvent'])) {
            $errors[] = 'birthEvent object required';
        } else {
            $be = $payload['birthEvent'];
            if (!self::validateBirthEventType($be['type'] ?? '')) $errors[] = 'Invalid birth type';
            if (!self::validateDate($be['dateOfBirth'] ?? '')) $errors[] = 'Invalid or missing dateOfBirth';
            if (!self::validateTier((int)($be['notifierTier'] ?? -1))) $errors[] = 'Invalid notifier tier';
        }

        if (empty($payload['child']) || !is_array($payload['child'])) {
            $errors[] = 'child object required';
        } else {
            $ch = $payload['child'];
            if (empty(trim($ch['firstName'] ?? ''))) $errors[] = 'Child firstName required';
            if (empty(trim($ch['lastName'] ?? ''))) $errors[] = 'Child lastName required';
            if (!self::validateSex($ch['sex'] ?? '')) $errors[] = 'Invalid child sex';
        }

        if (empty($payload['mother']) || !is_array($payload['mother'])) {
            $errors[] = 'mother object required';
        } else {
            $mo = $payload['mother'];
            if (empty(trim($mo['fullName'] ?? ''))) $errors[] = 'Mother fullName required';
            if (!self::validateMaritalStatus($mo['maritalStatus'] ?? '')) $errors[] = 'Invalid marital status';
        }

        return ['valid' => empty($errors), 'errors' => $errors];
    }
}
