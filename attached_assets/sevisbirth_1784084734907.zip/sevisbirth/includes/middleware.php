<?php
/* ============================================================
   FILE: includes/middleware.php
   Authentication Middleware — validates SSO sessions
   ============================================================ */

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../database.php';

class Middleware {

    public static function authenticate(?string $sessionId): array {
        if (empty($sessionId)) {
            return ['authenticated' => false, 'user' => null, 'error' => 'Missing session ID'];
        }

        $db = Database::getInstance();
        $stmt = $db->prepare("
            SELECT s.*, u.name, u.email, u.role, u.tier, u.facility_code, u.facility_name, u.sub, u.sevispass_id
            FROM sso_sessions s
            JOIN mock_users u ON s.user_sub = u.sub
            WHERE s.id = ? AND s.authenticated = 1 AND s.expires_at > datetime('now')
        ");
        $stmt->execute([$sessionId]);
        $row = $stmt->fetch();

        if (!$row) {
            return ['authenticated' => false, 'user' => null, 'error' => 'Session invalid or expired'];
        }

        return [
            'authenticated' => true,
            'user' => [
                'sub' => $row['sub'],
                'name' => $row['name'],
                'email' => $row['email'],
                'role' => $row['role'],
                'tier' => (int) $row['tier'],
                'facilityCode' => $row['facility_code'],
                'facilityName' => $row['facility_name'],
                'sevispassId' => $row['sevispass_id']
            ],
            'error' => null
        ];
    }

    public static function requireAuth(): array {
        $sessionId = $_GET['session'] ?? $_SERVER['HTTP_AUTHORIZATION'] ?? null;

        if ($sessionId && str_starts_with($sessionId, 'Bearer ')) {
            $sessionId = substr($sessionId, 7);
        }

        $result = self::authenticate($sessionId);
        if (!$result['authenticated']) {
            http_response_code(401);
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'error' => $result['error']]);
            exit;
        }

        return $result['user'];
    }

    public static function requireRole(array $user, array $roles): void {
        if (!in_array($user['role'], $roles, true)) {
            http_response_code(403);
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'error' => "Role '{$user['role']}' not authorized for this action"]);
            exit;
        }
    }

    public static function jsonResponse(array $data, int $code = 200): void {
        http_response_code($code);
        header('Content-Type: application/json');
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Client-ID, X-Client-Secret');
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
    }
}
