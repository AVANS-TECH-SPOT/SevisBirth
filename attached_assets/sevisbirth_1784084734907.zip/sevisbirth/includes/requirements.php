<?php
/* ============================================================
   FILE: includes/requirements.php
   Witness, Evidence, and Timing Requirements Engine
   Enforces PNG Civil and Identity Registration Act 2024 rules
   ============================================================ */

require_once __DIR__ . '/../config.php';

class Requirements {

    const TIER_LABELS = [
        0 => 'Village Health Volunteer',
        1 => 'Community Health Worker',
        2 => 'Nursing Officer',
        3 => 'Medical Officer',
        4 => 'Specialist'
    ];

    const TIER_SHORT = [
        0 => 'VHV',
        1 => 'CHW',
        2 => 'NO',
        3 => 'MO',
        4 => 'SP'
    ];

    const BIRTH_TYPES = [
        'facility_high', 'facility_low',
        'home_sba', 'home_tba', 'home_none', 'foundling'
    ];

    const EVIDENCE_MAP = [
        'facility_high'  => ['required' => ['birth_register'], 'recommended' => ['health_card']],
        'facility_low'   => ['required' => ['birth_register', 'witness_stmt'], 'recommended' => ['health_card']],
        'home_sba'       => ['required' => ['sba_attest'], 'recommended' => ['health_card', 'immunization']],
        'home_tba'       => ['required' => ['tba_stmt', 'witness_stmt'], 'recommended' => ['photo']],
        'home_none'      => ['required' => ['witness_stmt'], 'recommended' => ['immunization', 'baptism']],
        'foundling'      => ['required' => ['police_report', 'witness_stmt', 'welfare_report'], 'recommended' => ['photo']]
    ];

    const EVIDENCE_LABELS = [
        'birth_register' => 'Facility Birth Register Entry',
        'health_card' => 'Child Health Card',
        'immunization' => 'Immunization Record',
        'witness_stmt' => 'Witness Statement',
        'sba_attest' => 'SBA Attestation Form',
        'tba_stmt' => 'TBA Statement Form',
        'police_report' => 'Police Report',
        'welfare_report' => 'Social Welfare Assessment',
        'photo' => 'Photo of Birth Location',
        'baptism' => 'Baptism / Religious Record',
        'other_doc' => 'Supporting Document',
        'nid_copy' => 'National ID Card Copy',
        'passport_copy' => 'Passport Copy',
        'work_permit' => "Father's Work Permit"
    ];

    /**
     * Calculate witness requirements based on birth type and notifier tier.
     */
    public static function getWitnessRequirements(string $birthType, int $notifierTier): array {
        $result = ['count' => 0, 'minTier' => null, 'reasons' => []];

        switch ($birthType) {
            case 'foundling':
                $result['count'] = 2;
                $result['minTier'] = 1;
                $result['reasons'][] = 'Foundling: minimum 2 witnesses (T1+) required by law';
                break;

            case 'home_none':
                if ($notifierTier <= 1) {
                    $result['count'] = 2;
                    $result['minTier'] = 2;
                    $result['reasons'][] = "Notifier T{$notifierTier}: no-attendant birth requires 2 witnesses, min T2+";
                } else {
                    $result['count'] = 1;
                    $result['minTier'] = 1;
                    $result['reasons'][] = 'No-attendant birth: 1 witness (T1+) required';
                }
                break;

            case 'home_tba':
                if ($notifierTier <= 1) {
                    $result['count'] = 1;
                    $result['minTier'] = 2;
                    $result['reasons'][] = "Notifier T{$notifierTier}: TBA-attended birth requires T2+ counter-signing officer";
                } else {
                    $result['reasons'][] = 'No additional witness (T2+ notifier self-attests)';
                }
                break;

            case 'home_sba':
                if ($notifierTier === 0) {
                    $result['count'] = 1;
                    $result['minTier'] = 1;
                    $result['reasons'][] = 'VHV: SBA home birth requires T1+ witness';
                } else {
                    $result['reasons'][] = 'No additional witness (T1+ notifier)';
                }
                break;

            case 'facility_low':
                if ($notifierTier <= 1) {
                    $result['count'] = 1;
                    $result['minTier'] = 2;
                    $result['reasons'][] = 'Low-tier facility: requires T2+ counter-signing officer';
                } else {
                    $result['reasons'][] = 'No additional witness (T2+ notifier)';
                }
                break;

            case 'facility_high':
                $result['reasons'][] = 'No additional witness (Health Center+ facility)';
                break;
        }

        return $result;
    }

    /**
     * Get evidence requirements, adjusted for registration timing.
     */
    public static function getEvidenceRequirements(string $birthType, ?string $timingCategory): array {
        $map = self::EVIDENCE_MAP[$birthType] ?? self::EVIDENCE_MAP['home_none'];
        $required = array_map(fn($k) => ['key' => $k, 'label' => self::EVIDENCE_LABELS[$k] ?? $k], $map['required']);
        $recommended = array_map(fn($k) => ['key' => $k, 'label' => self::EVIDENCE_LABELS[$k] ?? $k], $map['recommended']);

        if ($timingCategory === 'late') {
            $recommended[] = ['key' => 'immunization', 'label' => 'Immunization Record (corroborating for late registration)'];
        }
        if ($timingCategory === 'very_late') {
            $required[] = ['key' => 'other_doc', 'label' => 'Supporting Document for Birth Date Verification'];
            $recommended[] = ['key' => 'baptism', 'label' => 'Baptism / Religious Record'];
        }

        return ['required' => $required, 'recommended' => $recommended];
    }

    /**
     * Calculate registration timing category per PNG CIR Act 2024.
     */
    public static function calcTiming(?string $dateOfBirth): ?array {
        if (!$dateOfBirth) return null;
        $days = (int) floor((time() - strtotime($dateOfBirth)) / 86400);
        $category = 'standard';
        $lateFee = false;
        $inquiry = false;

        if ($days > VERY_LATE_REGISTRATION_DAYS) {
            $category = 'very_late';
            $inquiry = true;
        } elseif ($days > LATE_REGISTRATION_DAYS) {
            $category = 'late';
            $lateFee = true;
        }

        return compact('category', 'days', 'lateFee', 'inquiry');
    }

    public static function checkWitnesses(array $requirements, array $witnesses): array {
        if ($requirements['count'] === 0) return ['met' => true, 'gap' => 0];

        $valid = array_filter($witnesses, fn($w) => !empty(trim($w['fullName'] ?? '')));
        $count = count($valid);

        if ($count < $requirements['count']) {
            return ['met' => false, 'gap' => $requirements['count'] - $count];
        }

        if ($requirements['minTier'] !== null) {
            foreach ($valid as $w) {
                if (($w['tier'] ?? 0) < $requirements['minTier']) {
                    return ['met' => false, 'gap' => 0, 'tierIssue' => true, 'minTier' => $requirements['minTier']];
                }
            }
        }

        return ['met' => true, 'gap' => 0];
    }

    public static function checkEvidence(array $requirements, array $evidence): array {
        $attached = array_filter($evidence, fn($e) => !empty($e['attached']));
        $attachedKeys = array_column($attached, 'type');
        $missing = [];

        foreach ($requirements['required'] as $req) {
            if (!in_array($req['key'], $attachedKeys)) {
                $missing[] = $req;
            }
        }

        return ['met' => empty($missing), 'missing' => $missing];
    }

    /**
     * Generate system flags for a record.
     */
    public static function generateFlags(array $data): array {
        $flags = [];
        $be = $data['birthEvent'] ?? [];
        $mo = $data['mother'] ?? [];
        $fa = $data['father'] ?? [];
        $ch = $data['child'] ?? [];

        // Timing
        $timing = self::calcTiming($be['dateOfBirth'] ?? null);
        if ($timing) {
            if ($timing['category'] === 'late') {
                $flags[] = ['sev' => 'warn', 'icon' => 'fa-clock',
                    'msg' => "Late registration: {$timing['days']} days. Late fee applicable."];
            }
            if ($timing['category'] === 'very_late') {
                $flags[] = ['sev' => 'error', 'icon' => 'fa-gavel',
                    'msg' => "Very late: {$timing['days']} days. Formal inquiry required."];
            }
        }

        // Mother age
        if (!empty($mo['dateOfBirth']) && !empty($be['dateOfBirth'])) {
            $age = floor((strtotime($be['dateOfBirth']) - strtotime($mo['dateOfBirth'])) / (365.25 * 86400));
            if ($age < 16) {
                $flags[] = ['sev' => 'error', 'icon' => 'fa-shield-halved',
                    'msg' => "Mother ~{$age} years old. Child protection referral may be required."];
            } elseif ($age < 18) {
                $flags[] = ['sev' => 'warn', 'icon' => 'fa-shield-halved',
                    'msg' => "Mother under 18 ({$age}y). Note for registrar."];
            }
        }

        // Single parent scenarios
        if (isset($fa['available']) && !$fa['available']) {
            $reason = $fa['unavailableReason'] ?? '';
            switch ($reason) {
                case 'deceased':
                    $flags[] = ['sev' => 'warn', 'icon' => 'fa-cross',
                        'msg' => 'Father deceased. Death certificate/attestation recommended.'];
                    break;
                case 'unknown':
                    $flags[] = ['sev' => 'info', 'icon' => 'fa-question',
                        'msg' => 'Father identity unknown. Proceeds with mother-only details.'];
                    break;
                case 'abandoned':
                    $flags[] = ['sev' => 'warn', 'icon' => 'fa-person-walking-away',
                        'msg' => 'Father alleged abandonment. Welfare referral may be appropriate.'];
                    break;
                case 'refused':
                    $flags[] = ['sev' => 'info', 'icon' => 'fa-ban',
                        'msg' => 'Father refused details. Paternity not legally established.'];
                    break;
            }
        }

        // Mother deceased
        if (($be['motherSurvived'] ?? true) === false) {
            $flags[] = ['sev' => 'error', 'icon' => 'fa-heart-crack',
                'msg' => 'Mother deceased. Additional witness/attestation and next-of-kin required.'];
        }

        // Multiple birth
        if (!empty($be['isMultipleBirth'])) {
            $flags[] = ['sev' => 'info', 'icon' => 'fa-people-group',
                'msg' => "Multiple birth: child {$be['multipleBirthOrder']} of {$be['multipleBirthTotal']}. Each child needs separate registration."];
        }

        // Missing birth weight
        if (empty($ch['birthWeight']) && ($be['type'] ?? '') !== 'foundling') {
            $flags[] = ['sev' => 'warn', 'icon' => 'fa-weight-scale',
                'msg' => 'Birth weight not recorded.'];
        }

        // Unmarried paternity
        if (($mo['maritalStatus'] ?? '') === 'single' && !empty($fa['available']) && empty($fa['acknowledgmentSigned'])) {
            $flags[] = ['sev' => 'warn', 'icon' => 'fa-file-signature',
                'msg' => 'Unmarried parents, paternity acknowledgment not signed.'];
        }

        return $flags;
    }

    /**
     * Full validation of a birth record for submission.
     */
    public static function validateForSubmission(array $data): array {
        $errors = [];
        $warnings = [];
        $be = $data['birthEvent'] ?? [];
        $ch = $data['child'] ?? [];
        $mo = $data['mother'] ?? [];
        $fa = $data['father'] ?? [];

        // Required fields
        if (empty($be['type'])) $errors[] = 'Birth type required';
        if (empty($be['dateOfBirth'])) $errors[] = 'Child DOB required';
        if (empty($ch['firstName'])) $errors[] = 'Child first name required';
        if (empty($ch['lastName'])) $errors[] = 'Child last name required';
        if (empty($ch['sex'])) $errors[] = 'Child sex required';

        if (empty($mo['fullName'])) $errors[] = 'Mother name required';
        if (empty($mo['dateOfBirth']) && empty($mo['useEstimatedAge'])) $errors[] = 'Mother DOB or estimated age required';
        if (!empty($mo['useEstimatedAge']) && empty($mo['estimatedAge'])) $errors[] = 'Estimated age required';
        if (empty($mo['nationality'])) $errors[] = 'Mother nationality required';
        if (empty($mo['maritalStatus'])) $errors[] = 'Mother marital status required';

        if (!empty($be['requiresFacility']) && empty($be['facilityName'])) {
            $errors[] = 'Facility name required';
        }
        if (empty($be['requiresFacility']) && empty($be['village'])) {
            $errors[] = 'Village required';
        }
        if (empty($be['district'])) $errors[] = 'District required';
        if (empty($be['province'])) $errors[] = 'Province required';

        // Witness check
        $witnessReqs = self::getWitnessRequirements($be['type'] ?? '', $be['notifierTier'] ?? 2);
        $witnessCheck = self::checkWitnesses($witnessReqs, $data['witnesses'] ?? []);
        if (!$witnessCheck['met']) {
            if (!empty($witnessCheck['tierIssue'])) {
                $errors[] = "Witness tier insufficient: min T{$witnessCheck['minTier']}";
            } else {
                $errors[] = "{$witnessCheck['gap']} witness(es) missing (need {$witnessReqs['count']})";
            }
        }

        // Evidence check
        $timing = self::calcTiming($be['dateOfBirth'] ?? null);
        $evidenceReqs = self::getEvidenceRequirements($be['type'] ?? '', $timing['category'] ?? null);
        $evidenceCheck = self::checkEvidence($evidenceReqs, $data['evidence'] ?? []);
        if (!$evidenceCheck['met']) {
            foreach ($evidenceCheck['missing'] as $m) {
                $errors[] = "Required evidence: {$m['label']}";
            }
        }

        // Warnings
        if (empty($ch['birthWeight'])) $warnings[] = 'Birth weight not recorded';
        if (!empty($fa) && empty($fa['available']) && empty($fa['unavailableReason'])) {
            $warnings[] = 'Father unavailable but no reason specified';
        }

        return [
            'valid' => empty($errors),
            'errors' => $errors,
            'warnings' => $warnings,
            'flags' => self::generateFlags($data)
        ];
    }
}
