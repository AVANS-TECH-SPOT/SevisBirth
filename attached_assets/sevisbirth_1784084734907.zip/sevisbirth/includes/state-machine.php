<?php
/* ============================================================
   FILE: includes/state-machine.php
   Record State Machine — Server-side transition enforcement
   ============================================================ */

class StateMachine {

    const STATES = [
        'draft', 'submitted', 'received', 'reviewing',
        'approved', 'rejected', 'certifying', 'complete',
        'failed', 'voided'
    ];

    const STATE_LABELS = [
        'draft' => 'Draft',
        'submitted' => 'Submitted',
        'received' => 'Received',
        'reviewing' => 'Reviewing',
        'approved' => 'Approved',
        'rejected' => 'Rejected',
        'certifying' => 'Certifying',
        'complete' => 'Complete',
        'failed' => 'Failed',
        'voided' => 'Voided'
    ];

    /**
     * Valid transitions: from_state => [to_state => [roles, label]]
     */
    const TRANSITIONS = [
        'draft' => [
            'submitted' => ['roles' => ['field_worker'], 'label' => 'Submit']
        ],
        'submitted' => [
            'received' => ['roles' => ['system'], 'label' => 'Sync Success'],
            'failed' => ['roles' => ['system'], 'label' => 'Sync Failed']
        ],
        'failed' => [
            'submitted' => ['roles' => ['field_worker'], 'label' => 'Retry']
        ],
        'received' => [
            'reviewing' => ['roles' => ['system'], 'label' => 'Auto-assign']
        ],
        'reviewing' => [
            'approved' => ['roles' => ['civil_registrar'], 'label' => 'Approve'],
            'rejected' => ['roles' => ['civil_registrar'], 'label' => 'Reject']
        ],
        'rejected' => [
            'submitted' => ['roles' => ['field_worker'], 'label' => 'Resubmit']
        ],
        'approved' => [
            'certifying' => ['roles' => ['system'], 'label' => 'Generate Certificate']
        ],
        'certifying' => [
            'complete' => ['roles' => ['system'], 'label' => 'Certificate Ready']
        ],
        'complete' => [
            'voided' => ['roles' => ['registrar_general'], 'label' => 'Void']
        ]
    ];

    public static function isValidState(string $state): bool {
        return in_array($state, self::STATES, true);
    }

    public static function canTransition(string $from, string $to, string $actorRole): array {
        if (!isset(self::TRANSITIONS[$from][$to])) {
            return ['allowed' => false, 'error' => "Cannot transition from {$from} to {$to}"];
        }

        $rule = self::TRANSITIONS[$from][$to];

        if (in_array('system', $rule['roles'])) {
            return ['allowed' => true, 'label' => $rule['label']];
        }

        if (!in_array($actorRole, $rule['roles'])) {
            return ['allowed' => false, 'error' => "Role '{$actorRole}' cannot perform this transition"];
        }

        return ['allowed' => true, 'label' => $rule['label']];
    }

    public static function executeTransition(
        PDO $db,
        string $recordId,
        string $toState,
        string $actorName,
        string $actorRole,
        string $reason = ''
    ): array {
        $stmt = $db->prepare("SELECT state FROM birth_records WHERE id = ?");
        $stmt->execute([$recordId]);
        $row = $stmt->fetch();
        if (!$row) {
            return ['success' => false, 'error' => 'Record not found'];
        }

        $fromState = $row['state'];

        $check = self::canTransition($fromState, $toState, $actorRole);
        if (!$check['allowed']) {
            return ['success' => false, 'error' => $check['error']];
        }

        $now = gmdate('Y-m-d\TH:i:s\Z');
        $stmt = $db->prepare("UPDATE birth_records SET state = ?, updated_at = ? WHERE id = ?");
        $stmt->execute([$toState, $now, $recordId]);

        $stmt = $db->prepare("INSERT INTO state_history (record_id, from_state, to_state, actor_name, actor_role, reason, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$recordId, $fromState, $toState, $actorName, $actorRole, $reason, $now]);

        return ['success' => true, 'newState' => $toState, 'previousState' => $fromState, 'label' => $check['label']];
    }

    public static function autoAdvance(PDO $db, string $recordId): void {
        $systemTransitions = [
            'submitted' => 'received',
            'received' => 'reviewing',
            'approved' => 'certifying',
            'certifying' => 'complete'
        ];

        // Loop through every consecutive automatic (system-only) transition
        // instead of stopping after a single step, so a record doesn't get
        // stuck (e.g. sitting in 'received' and never reaching 'reviewing').
        // The 4-iteration cap matches the number of system transitions above
        // and guards against an infinite loop if the map is ever misconfigured.
        for ($i = 0; $i < 4; $i++) {
            $stmt = $db->prepare("SELECT state FROM birth_records WHERE id = ?");
            $stmt->execute([$recordId]);
            $row = $stmt->fetch();
            if (!$row) return;

            $state = $row['state'];
            if (!isset($systemTransitions[$state])) return;

            self::executeTransition($db, $recordId, $systemTransitions[$state], 'System', 'system');
        }
    }
}
