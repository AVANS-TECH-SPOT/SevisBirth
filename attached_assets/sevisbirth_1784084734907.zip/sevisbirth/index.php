<?php
/* ============================================================
   FILE: index.php
   Application Entry Point — Serves the SPA Shell
   ============================================================ */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SevisBirth — Digital Birth Registration | Papua New Guinea</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="assets/style.css">
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        forest: {
                            50:'#E4EDE8',100:'#C5D9CC',200:'#8BAA98',300:'#5C8A6E',
                            400:'#3D6B4F',500:'#245038',600:'#1A3729',700:'#132B20',
                            800:'#0B1D15',900:'#071210'
                        },
                        gold: {300:'#F0CC5E',400:'#E5B340',500:'#C9962A',600:'#A67B20'}
                    },
                    fontFamily: {
                        sans: ['Plus Jakarta Sans','sans-serif'],
                        mono: ['JetBrains Mono','monospace']
                    }
                }
            }
        };
    </script>
</head>
<body>
    <!-- Login Screen -->
    <div id="login-screen" class="login-bg fixed inset-0 z-50 flex items-center justify-center">
        <div class="text-center max-w-md px-6">
            <div class="mb-8 fade-up">
                <div class="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-forest-600 border border-forest-500 mb-5">
                    <i class="fa-solid fa-baby text-3xl text-gold-400"></i>
                </div>
                <h1 class="font-sans text-4xl font-900 tracking-tight mb-2">SevisBirth</h1>
                <p class="text-forest-200 text-sm font-light tracking-wide">Digital Birth Registration — Papua New Guinea</p>
                <p class="text-forest-400 text-xs mt-2 font-mono">PNG Civil & Identity Registration Act 2024</p>
            </div>

            <div id="auth-area">
                <div id="loading-indicator" class="py-8">
                    <i class="fa-solid fa-spinner spin text-xl text-gold-400"></i>
                    <p class="text-forest-200 text-sm mt-3">Loading SevisPass...</p>
                </div>
            </div>

            <p class="text-forest-400 text-[10px] mt-8 font-mono">Prototype v2.0 — PHP Backend — OIDC4VP Mock</p>
        </div>
    </div>

    <!-- App Shell (hidden until login) -->
    <div id="app-shell" class="hidden h-screen flex">
        <aside class="w-56 flex-shrink-0 bg-forest-700 border-r border-forest-500 flex flex-col h-screen">
            <div class="p-4 border-b border-forest-500">
                <div class="flex items-center gap-3">
                    <div class="w-8 h-8 rounded-lg bg-forest-600 flex items-center justify-center">
                        <i class="fa-solid fa-baby text-gold-400 text-xs"></i>
                    </div>
                    <div>
                        <p class="font-sans font-800 text-sm leading-tight">SevisBirth</p>
                        <p class="text-[10px] text-forest-200 font-mono">PNG Digital Registry</p>
                    </div>
                </div>
            </div>
            <nav class="flex-1 py-2 overflow-y-auto" id="nav-list"></nav>
            <div class="p-3 border-t border-forest-500 space-y-2">
                <div id="offline-ind" class="flex items-center gap-2 text-xs">
                    <span class="w-2 h-2 rounded-full bg-emerald-400 inline-block"></span>
                    <span class="text-emerald-400 font-mono">API Connected</span>
                </div>
                <div class="flex items-center gap-2 text-xs text-forest-200">
                    <i class="fa-solid fa-lock text-[10px] text-emerald-400"></i>
                    <span class="font-mono">AES-256-GCM Server-Side</span>
                </div>
            </div>
            <div class="p-3 border-t border-forest-500">
                <div class="flex items-center gap-2">
                    <div class="w-7 h-7 rounded-full bg-forest-600 flex items-center justify-center text-[10px] font-bold text-gold-400" id="u-avatar"></div>
                    <div class="flex-1 min-w-0">
                        <p class="text-xs font-semibold truncate" id="u-name"></p>
                        <p class="text-[10px] text-forest-200 font-mono" id="u-role"></p>
                    </div>
                    <button onclick="logout()" class="text-forest-200 hover:text-red-400 transition-colors" title="Logout">
                        <i class="fa-solid fa-right-from-bracket text-xs"></i>
                    </button>
                </div>
            </div>
        </aside>
        <div class="flex-1 flex flex-col h-screen overflow-hidden bg-dots">
            <header class="flex-shrink-0 bg-forest-800/80 backdrop-blur border-b border-forest-500 flex items-center px-6 justify-between" style="height:52px">
                <h2 id="page-title" class="font-sans font-700 text-base"></h2>
                <div class="flex items-center gap-3">
                    <span class="text-[11px] text-forest-200 font-mono" id="hdr-date"></span>
                    <span class="tier-badge tier-0" id="hdr-tier"></span>
                </div>
            </header>
            <main id="content" class="flex-1 overflow-y-auto p-6"></main>
        </div>
    </div>

    <div id="toast-c" class="fixed top-4 right-4 z-[200] space-y-2 pointer-events-none" style="max-width:380px"></div>
    <div id="modal-c" class="hidden"></div>

    <script src="assets/app.js"></script>
</body>
</html>
