<?php
/* ============================================================
   FILE: mock_sevispass.php
   Mock OIDC4VP SSO Server with Bypass Mode

   Endpoints (via ?action= parameter):
     - authorize    : Initiate auth, return QR code SVG
     - status       : Poll session status
     - scan         : Simulate wallet QR scan (complete auth)
     - bypass       : Direct login bypass (no QR needed)
     - user         : Get user data for session
     - logout       : Destroy session
     - users        : List available mock users (for bypass UI)
   ============================================================ */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/database.php';
require_once __DIR__ . '/includes/middleware.php';

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, X-Client-ID, X-Client-Secret');
    exit;
}

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

// The frontend sends request bodies as JSON (Content-Type: application/json).
// PHP only auto-populates $_POST for application/x-www-form-urlencoded or
// multipart/form-data bodies, so without this, every $_POST['...'] lookup
// below (user_sub, session, callback_url, etc.) would silently come back
// empty. Decode the raw JSON body and merge it into $_POST so the rest of
// this file can keep using the simple $_POST[...] access pattern.
$rawInput = file_get_contents('php://input');
if ($rawInput !== false && $rawInput !== '') {
    $jsonBody = json_decode($rawInput, true);
    if (is_array($jsonBody)) {
        $_POST = array_merge($_POST, $jsonBody);
    }
}

$action = isset($_GET['action']) ? $_GET['action'] : (isset($_POST['action']) ? $_POST['action'] : '');
$db = Database::getInstance();

try {
    switch ($action) {

        case 'users':
            $stmt = $db->query("SELECT sub, name, role, tier, facility_name, sevispass_id FROM mock_users ORDER BY role, tier");
            Middleware::jsonResponse(['success' => true, 'users' => $stmt->fetchAll()]);
            break;

        case 'authorize':
            $sessionId = 'ss-' . bin2hex(random_bytes(12));
            $state = bin2hex(random_bytes(16));
            $nonce = bin2hex(random_bytes(16));
            $expiresAt = gmdate('Y-m-d\TH:i:s\Z', time() + (SESSION_LIFETIME_HOURS * 3600));

            $stmt = $db->prepare("INSERT INTO sso_sessions (id, state, nonce, callback_url, created_at, expires_at) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([
                $sessionId,
                $state,
                $nonce,
                $_POST['callback_url'] ?? '',
                gmdate('Y-m-d\TH:i:s\Z'),
                $expiresAt
            ]);

            Middleware::jsonResponse([
                'success' => true,
                'sessionId' => $sessionId,
                'state' => $state,
                'nonce' => $nonce,
                'qrCode' => generateQRSVG($sessionId),
                'bypassAvailable' => SEVISPASS_BYPASS
            ]);
            break;

        case 'status':
            $sessionId = $_GET['session'] ?? '';
            if (empty($sessionId)) {
                Middleware::jsonResponse(['success' => false, 'error' => 'Missing session parameter'], 400);
                break;
            }

            $stmt = $db->prepare("SELECT authenticated, user_sub FROM sso_sessions WHERE id = ?");
            $stmt->execute([$sessionId]);
            $row = $stmt->fetch();

            if (!$row) {
                Middleware::jsonResponse(['success' => false, 'error' => 'Session not found'], 404);
                break;
            }

            Middleware::jsonResponse([
                'success' => true,
                'sessionId' => $sessionId,
                'authenticated' => (bool) $row['authenticated'],
                'hasRedirect' => (bool) $row['authenticated'],
                'redirect' => $row['authenticated'] ? "/api.php?route=user&session={$sessionId}" : null
            ]);
            break;

        case 'scan':
            $sessionId = $_POST['session'] ?? $_GET['session'] ?? '';
            $userSub = $_POST['user_sub'] ?? null;

            if (empty($sessionId)) {
                Middleware::jsonResponse(['success' => false, 'error' => 'Missing session'], 400);
                break;
            }

            if (empty($userSub)) {
                $userSub = $db->query("SELECT sub FROM mock_users LIMIT 1")->fetchColumn();
            }

            $stmt = $db->prepare("SELECT * FROM mock_users WHERE sub = ?");
            $stmt->execute([$userSub]);
            $user = $stmt->fetch();
            if (!$user) {
                Middleware::jsonResponse(['success' => false, 'error' => 'User not found'], 404);
                break;
            }

            $vpToken = json_encode([
                '@context' => ['https://www.w3.org/2018/credentials/v1'],
                'type' => ['VerifiablePresentation'],
                'verifiableCredential' => [[
                    '@context' => ['https://www.w3.org/2018/credentials/v1'],
                    'type' => ['VerifiableCredential', 'SevisPassIdentity'],
                    'credentialSubject' => [
                        'sub' => $user['sub'],
                        'name' => $user['name'],
                        'role' => $user['role'],
                        'email' => $user['email'],
                        'tier' => (int) $user['tier'],
                        'sevispassId' => $user['sevispass_id']
                    ],
                    'proof' => [
                        'type' => 'Ed25519Signature2020',
                        'created' => gmdate('Y-m-d\TH:i:s\Z'),
                        'verificationMethod' => $user['sub'] . '#key-1',
                        'proofValue' => 'mock-signature-' . bin2hex(random_bytes(32))
                    ]
                ]],
                'proof' => [
                    'type' => 'Ed25519Signature2020',
                    'proofValue' => 'mock-presentation-signature-' . bin2hex(random_bytes(32))
                ]
            ], JSON_UNESCAPED_UNICODE);

            $stmt = $db->prepare("UPDATE sso_sessions SET authenticated = 1, vp_token = ?, user_sub = ? WHERE id = ?");
            $stmt->execute([$vpToken, $userSub, $sessionId]);

            Middleware::jsonResponse([
                'success' => true,
                'sessionId' => $sessionId,
                'message' => 'Credential verified: ' . $user['name']
            ]);
            break;

        case 'bypass':
            if (!SEVISPASS_BYPASS) {
                Middleware::jsonResponse(['success' => false, 'error' => 'Bypass mode disabled. Use QR flow.'], 403);
                break;
            }

            $userSub = $_POST['user_sub'] ?? $_GET['user_sub'] ?? '';
            if (empty($userSub)) {
                Middleware::jsonResponse(['success' => false, 'error' => 'Missing user_sub parameter'], 400);
                break;
            }

            $stmt = $db->prepare("SELECT * FROM mock_users WHERE sub = ?");
            $stmt->execute([$userSub]);
            $user = $stmt->fetch();
            if (!$user) {
                Middleware::jsonResponse(['success' => false, 'error' => 'User not found'], 404);
                break;
            }

            $sessionId = 'ss-bypass-' . bin2hex(random_bytes(8));
            $expiresAt = gmdate('Y-m-d\TH:i:s\Z', time() + (SESSION_LIFETIME_HOURS * 3600));

            $vpToken = json_encode([
                '@context' => ['https://www.w3.org/2018/credentials/v1'],
                'type' => ['VerifiablePresentation'],
                'verifiableCredential' => [[
                    'type' => ['VerifiableCredential', 'SevisPassIdentity'],
                    'credentialSubject' => [
                        'sub' => $user['sub'],
                        'name' => $user['name'],
                        'role' => $user['role'],
                        'tier' => (int) $user['tier'],
                        'sevispassId' => $user['sevispass_id']
                    ]
                ]],
                'proof' => ['type' => 'BypassMode', 'proofValue' => 'bypass-' . bin2hex(random_bytes(16))]
            ], JSON_UNESCAPED_UNICODE);

            $stmt = $db->prepare("INSERT INTO sso_sessions (id, state, nonce, authenticated, vp_token, user_sub, created_at, expires_at) VALUES (?, ?, ?, 1, ?, ?, ?, ?)");
            $stmt->execute([
                $sessionId,
                bin2hex(random_bytes(16)),
                bin2hex(random_bytes(16)),
                $vpToken,
                $userSub,
                gmdate('Y-m-d\TH:i:s\Z'),
                $expiresAt
            ]);

            Middleware::jsonResponse([
                'success' => true,
                'sessionId' => $sessionId,
                'bypass' => true,
                'user' => [
                    'sub' => $user['sub'],
                    'name' => $user['name'],
                    'email' => $user['email'],
                    'role' => $user['role'],
                    'tier' => (int) $user['tier'],
                    'facilityCode' => $user['facility_code'],
                    'facilityName' => $user['facility_name'],
                    'sevispassId' => $user['sevispass_id']
                ]
            ]);
            break;

        case 'user':
            $sessionId = $_GET['session'] ?? '';
            $auth = Middleware::authenticate($sessionId);
            if (!$auth['authenticated']) {
                Middleware::jsonResponse(['success' => false, 'error' => $auth['error']], 401);
                break;
            }
            Middleware::jsonResponse(['success' => true, 'user' => $auth['user'], 'sessionId' => $sessionId]);
            break;

        case 'logout':
            $sessionId = $_POST['session'] ?? $_GET['session'] ?? '';
            if (!empty($sessionId)) {
                $stmt = $db->prepare("DELETE FROM sso_sessions WHERE id = ?");
                $stmt->execute([$sessionId]);
            }
            Middleware::jsonResponse(['success' => true, 'message' => 'Logged out']);
            break;

        default:
            Middleware::jsonResponse([
                'success' => false,
                'error' => "Unknown action: {$action}. Valid: users, authorize, status, scan, bypass, user, logout",
                'bypassEnabled' => SEVISPASS_BYPASS
            ], 400);
    }
} catch (Exception $e) {
    Middleware::jsonResponse(['success' => false, 'error' => 'Server error: ' . $e->getMessage()], 500);
}

function generateQRSVG(string $sessionId): string {
    $n = 25;
    $cs = 180 / $n;
    $svg = '<svg xmlns="http://www.w3.org/2000/svg" width="180" height="180" viewBox="0 0 180 180" style="display:block">';

    $finder = function (int $ox, int $oy) use ($cs): string {
        $s = '';
        for ($y = 0; $y < 7; $y++) {
            for ($x = 0; $x < 7; $x++) {
                $filled = $y === 0 || $y === 6 || $x === 0 || $x === 6 || ($x >= 2 && $x <= 4 && $y >= 2 && $y <= 4);
                if ($filled) {
                    $s .= sprintf('<rect x="%.1f" y="%.1f" width="%.1f" height="%.1f" fill="#0B1D15"/>',
                        ($ox + $x) * $cs, ($oy + $y) * $cs, $cs + 0.5, $cs + 0.5);
                }
            }
        }
        return $s;
    };

    $svg .= $finder(0, 0) . $finder($n - 7, 0) . $finder(0, $n - 7);

    $seed = crc32($sessionId);
    for ($y = 0; $y < $n; $y++) {
        for ($x = 0; $x < $n; $x++) {
            if (($x < 8 && $y < 8) || ($x >= $n - 8 && $y < 8) || ($x < 8 && $y >= $n - 8)) continue;
            $seed = ($seed * 16807 + 7) % 2147483647;
            if (($seed % 100) < 48) {
                $opacity = 0.7 + (($seed % 30) / 100);
                $svg .= sprintf('<rect x="%.1f" y="%.1f" width="%.1f" height="%.1f" fill="#0B1D15" opacity="%.2f"/>',
                    $x * $cs, $y * $cs, $cs + 0.5, $cs + 0.5, $opacity);
            }
        }
    }

    $cx = (($n / 2) - 2) * $cs;
    $svg .= sprintf('<rect x="%.1f" y="%.1f" width="%.1f" height="%.1f" rx="2" fill="#0B1D15"/>', $cx, $cx, 5 * $cs, 5 * $cs);
    $svg .= sprintf('<text x="%.1f" y="%.1f" text-anchor="middle" fill="#C9962A" font-size="%.1f" font-weight="900">&#xf222;</text>',
        $cx + 2.5 * $cs, $cx + 3.4 * $cs, 2.5 * $cs);

    $svg .= '</svg>';
    return $svg;
}
