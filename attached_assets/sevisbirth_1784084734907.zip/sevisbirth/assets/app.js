/* ============================================================
   FILE: assets/app.js
   SevisBirth Frontend SPA — talks to PHP API backend
   Plus Jakarta Sans + JetBrains Mono
   ============================================================ */

const API = './api.php';
const SSO = './mock_sevispass.php';

const PROVINCES = [
    'National Capital District','Central','Chimbu','Eastern Highlands','East New Britain',
    'East Sepik','Enga','Gulf','Hela','Jiwaka','Madang','Manus','Milne Bay','Morobe',
    'New Ireland','Northern (Oro)','Bougainville','Southern Highlands','Western',
    'West New Britain','West Sepik (Sandaun)','Western Highlands'
];

const TIERS = {
    0:{label:'Village Health Volunteer',short:'VHV'},
    1:{label:'Community Health Worker',short:'CHW'},
    2:{label:'Nursing Officer',short:'NO'},
    3:{label:'Medical Officer',short:'MO'},
    4:{label:'Specialist',short:'SP'}
};

const BTYPES = {
    facility_high:{label:'Facility Birth — Health Center or Hospital',icon:'fa-hospital',reqFac:true},
    facility_low:{label:'Facility Birth — Aid Post / Clinic',icon:'fa-house-medical',reqFac:true},
    home_sba:{label:'Home Birth — Skilled Birth Attendant',icon:'fa-user-doctor',reqFac:false},
    home_tba:{label:'Home Birth — Traditional Birth Attendant',icon:'fa-hands-holding-child',reqFac:false},
    home_none:{label:'Home Birth — No Attendant Present',icon:'fa-house-chimney',reqFac:false},
    foundling:{label:'Foundling / Abandoned Infant',icon:'fa-child',reqFac:false}
};

const EV_LABELS = {
    birth_register:'Facility Birth Register Entry',
    health_card:'Child Health Card',
    immunization:'Immunization Record',
    witness_stmt:'Witness Statement',
    sba_attest:'SBA Attestation Form',
    tba_stmt:'TBA Statement Form',
    police_report:'Police Report',
    welfare_report:'Social Welfare Assessment',
    photo:'Photo of Birth Location',
    baptism:'Baptism / Religious Record',
    other_doc:'Supporting Document',
    nid_copy:'National ID Card Copy',
    passport_copy:'Passport Copy',
    work_permit:"Father's Work Permit"
};

const ST_L = {
    draft:'Draft',submitted:'Submitted',received:'Received',reviewing:'Reviewing',
    approved:'Approved',rejected:'Rejected',certifying:'Certifying',
    complete:'Complete',failed:'Failed',voided:'Voided'
};

const BADGE_C = {
    draft:'b-draft',submitted:'b-submitted',received:'b-received',reviewing:'b-reviewing',
    approved:'b-approved',rejected:'b-rejected',certifying:'b-certifying',
    complete:'b-complete',failed:'b-failed',voided:'b-voided'
};

/* ===== APP STATE ===== */
const APP = {
    user: null, sessionId: null, view: 'dashboard', formStep: 0,
    fd: null, bypassUsers: [], bypassMode: false
};

/* ===== UTILS ===== */
const $ = id => document.getElementById(id);
const fmtD = d => d ? new Date(d).toLocaleDateString('en-GB',{day:'2-digit',month:'short',year:'numeric'}) : '—';
const fmtDT = d => d ? new Date(d).toLocaleDateString('en-GB',{day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'}) : '—';
const stB = s => `<span class="badge ${BADGE_C[s]||'b-draft'}">${ST_L[s]||s}</span>`;
const tB = t => `<span class="tier-badge tier-${t}">T${t} ${TIERS[t]?.short||''}</span>`;

function toast(msg, type='info') {
    const c = $('toast-c');
    const cols = {
        info:'border-sky-500 bg-sky-950/90',
        success:'border-emerald-500 bg-emerald-950/90',
        error:'border-red-500 bg-red-950/90',
        warning:'border-amber-500 bg-amber-950/90'
    };
    const icons = {
        info:'fa-circle-info text-sky-400',
        success:'fa-circle-check text-emerald-400',
        error:'fa-circle-xmark text-red-400',
        warning:'fa-triangle-exclamation text-amber-400'
    };
    const el = document.createElement('div');
    el.className = `toast-in pointer-events-auto flex items-start gap-3 px-4 py-3 rounded-lg border ${cols[type]} backdrop-blur text-sm font-sans`;
    el.innerHTML = `<i class="fa-solid ${icons[type]} mt-0.5"></i><span>${msg}</span>`;
    c.appendChild(el);
    setTimeout(() => { el.style.opacity='0'; el.style.transition='opacity .3s'; setTimeout(()=>el.remove(),300); }, 4000);
}

function showModal(h) {
    $('modal-c').className='';
    $('modal-c').innerHTML=`<div class="modal-ov" onclick="if(event.target===this)closeModal()"><div class="modal-box fade-up">${h}</div></div>`;
}
function closeModal() { $('modal-c').className='hidden'; $('modal-c').innerHTML=''; }

async function apiGet(route) {
    const url = `${API}?route=${route}&session=${APP.sessionId}`;
    const res = await fetch(url);
    const data = await res.json();
    if (!data.success) throw new Error(data.error || 'API error');
    return data;
}

async function apiPost(route, body = {}) {
    const url = `${API}?route=${route}&session=${APP.sessionId}`;
    const res = await fetch(url, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body) });
    const data = await res.json();
    if (!data.success) throw new Error(data.error || 'API error');
    return data;
}

async function ssoPost(action, body = {}) {
    const res = await fetch(`${SSO}?action=${action}`, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body) });
    return res.json();
}

async function ssoGet(action) {
    const res = await fetch(`${SSO}?action=${action}&session=${APP.sessionId}`);
    return res.json();
}

/* ===== REQUIREMENTS ENGINE (client-side for real-time UI) ===== */
function getWitnessReqs(bt, nt) {
    const r = {count:0, minTier:null, reasons:[]};
    if(bt==='foundling'){r.count=2;r.minTier=1;r.reasons.push('Foundling: min 2 witnesses (T1+)');return r}
    if(bt==='home_none'){if(nt<=1){r.count=2;r.minTier=2;r.reasons.push(`T${nt}: no-attendant needs 2 witnesses min T2+`)}else{r.count=1;r.minTier=1;r.reasons.push('No-attendant: 1 witness T1+')}return r}
    if(bt==='home_tba'){if(nt<=1){r.count=1;r.minTier=2;r.reasons.push(`T${nt}: TBA birth needs T2+ counter-sign`)}else r.reasons.push('No extra witness (T2+)');return r}
    if(bt==='home_sba'){if(nt===0){r.count=1;r.minTier=1;r.reasons.push('VHV: SBA birth needs T1+ witness')}else r.reasons.push('No extra witness (T1+)');return r}
    if(bt==='facility_low'){if(nt<=1){r.count=1;r.minTier=2;r.reasons.push('Low-tier facility: T2+ counter-sign')}else r.reasons.push('No extra witness (T2+)');return r}
    r.reasons.push('No extra witness (HC+ facility)');return r;
}

function getEvidenceReqs(bt, tc) {
    const map = {
        facility_high:{req:['birth_register'],rec:['health_card']},
        facility_low:{req:['birth_register','witness_stmt'],rec:['health_card']},
        home_sba:{req:['sba_attest'],rec:['health_card','immunization']},
        home_tba:{req:['tba_stmt','witness_stmt'],rec:['photo']},
        home_none:{req:['witness_stmt'],rec:['immunization','baptism']},
        foundling:{req:['police_report','witness_stmt','welfare_report'],rec:['photo']}
    };
    const m = map[bt]||map.home_none;
    const required = m.req.map(k=>({key:k,label:EV_LABELS[k]||k}));
    const recommended = m.rec.map(k=>({key:k,label:EV_LABELS[k]||k}));
    if(tc==='late') recommended.push({key:'immunization',label:'Immunization (corroborating)'});
    if(tc==='very_late'){required.push({key:'other_doc',label:'Birth Date Verification Document'});recommended.push({key:'baptism',label:'Baptism / Religious Record'})}
    return {required, recommended};
}

function calcTiming(dob) {
    if(!dob) return null;
    const d = Math.floor((Date.now()-new Date(dob).getTime())/864e5);
    let cat='standard', fee=false, inquiry=false;
    if(d>365){cat='very_late';inquiry=true}else if(d>90){cat='late';fee=true}
    return {category:cat, days:d, lateFee:fee, inquiry};
}

function checkWitnessesMet(reqs, w) {
    if(reqs.count===0) return {met:true,gap:0};
    const v = (w||[]).filter(x=>(x.fullName||'').trim());
    if(v.length<reqs.count) return {met:false,gap:reqs.count-v.length};
    if(reqs.minTier!==null && !v.every(x=>(x.tier||0)>=reqs.minTier)) return {met:false,gap:0,tierIssue:true,minTier:reqs.minTier};
    return {met:true,gap:0};
}

function checkEvidenceMet(er, ev) {
    const k = (ev||[]).filter(e=>e.attached).map(e=>e.type);
    const missing = er.required.filter(r=>!k.includes(r.key));
    return {met:missing.length===0, missing};
}

function calcFlags(fd) {
    const flags=[], be=fd.birthEvent||{}, mo=fd.mother||{}, fa=fd.father||{}, ch=fd.child||{};
    const t=calcTiming(be.dateOfBirth);
    if(t){if(t.category==='late')flags.push({sev:'warn',icon:'fa-clock',msg:`Late: ${t.days} days. Late fee.`});if(t.category==='very_late')flags.push({sev:'error',icon:'fa-gavel',msg:`Very late: ${t.days} days. Inquiry required.`})}
    if(mo.dateOfBirth&&be.dateOfBirth){const a=Math.floor((new Date(be.dateOfBirth)-new Date(mo.dateOfBirth))/(365.25*864e5));if(a<16)flags.push({sev:'error',icon:'fa-shield-halved',msg:`Mother ~${a}y. Child protection referral.`});else if(a<18)flags.push({sev:'warn',icon:'fa-shield-halved',msg:`Mother under 18 (${a}y).`})}
    if(fa&&!fa.available){if(fa.unavailableReason==='deceased')flags.push({sev:'warn',icon:'fa-cross',msg:'Father deceased. Death cert recommended.'});else if(fa.unavailableReason==='unknown')flags.push({sev:'info',icon:'fa-question',msg:'Father unknown. Mother-only details.'});else if(fa.unavailableReason==='abandoned')flags.push({sev:'warn',icon:'fa-person-walking-away',msg:'Father abandoned. Welfare referral.'});else if(fa.unavailableReason==='refused')flags.push({sev:'info',icon:'fa-ban',msg:'Father refused details.'})}
    if(be.motherSurvived===false)flags.push({sev:'error',icon:'fa-heart-crack',msg:'Mother deceased. Extra witness + next-of-kin required.'});
    if(be.isMultipleBirth)flags.push({sev:'info',icon:'fa-people-group',msg:`Multiple birth: child ${be.multipleBirthOrder} of ${be.multipleBirthTotal}.`});
    if(!ch.birthWeight&&be.type!=='foundling')flags.push({sev:'warn',icon:'fa-weight-scale',msg:'Birth weight not recorded.'});
    if(mo.maritalStatus==='single'&&fa&&fa.available&&!fa.acknowledgmentSigned)flags.push({sev:'warn',icon:'fa-file-signature',msg:'Unmarried, paternity not signed.'});
    return flags;
}

function validateForSubmit(fd) {
    const errs=[],warns=[],be=fd.birthEvent||{},ch=fd.child||{},mo=fd.mother||{},fa=fd.father||{};
    if(!be.type)errs.push('Birth type required');if(!be.dateOfBirth)errs.push('DOB required');if(!ch.firstName)errs.push('Child first name');if(!ch.lastName)errs.push('Child last name');if(!ch.sex)errs.push('Child sex');
    if(!mo.fullName)errs.push('Mother name');if(!mo.dateOfBirth&&!mo.useEstimatedAge)errs.push('Mother DOB or est. age');if(mo.useEstimatedAge&&!mo.estimatedAge)errs.push('Est. age required');if(!mo.nationality)errs.push('Mother nationality');if(!mo.maritalStatus)errs.push('Marital status');
    if(be.requiresFacility&&!be.facilityName)errs.push('Facility name');if(!be.requiresFacility&&!be.village)errs.push('Village');if(!be.district)errs.push('District');if(!be.province)errs.push('Province');
    const wr=getWitnessReqs(be.type,be.notifierTier),wm=checkWitnessesMet(wr,fd.witnesses||[]);
    if(!wm.met){if(wm.tierIssue)errs.push(`Witness tier < T${wm.minTier}`);else errs.push(`${wm.gap} witness(es) missing`)}
    const er=getEvidenceReqs(be.type,calcTiming(be.dateOfBirth)?.category),em=checkEvidenceMet(er,fd.evidence||[]);
    if(!em.met)em.missing.forEach(m=>errs.push(`Evidence: ${m.label}`));
    if(!ch.birthWeight)warns.push('Weight not recorded');
    return {valid:errs.length===0,errors:errs,warnings:warns,flags:calcFlags(fd)};
}

/* ===== NEW FORM DATA ===== */
function newFd(){
    return {
        birthEvent:{
            type:'',dateOfBirth:'',timeOfBirth:'',isMultipleBirth:false,
            multipleBirthOrder:null,multipleBirthTotal:null,motherSurvived:true,
            facilityName:'',facilityCode:'',facilityTier:null,village:'',ward:'',llg:'',
            district:'',province:'',notifierTier:APP.user?.tier||2,requiresFacility:false
        },
        child:{firstName:'',lastName:'',sex:'',birthWeight:null,birthLength:null,congenitalAnomalies:''},
        mother:{
            fullName:'',dateOfBirth:'',useEstimatedAge:false,estimatedAge:null,
            nationality:'PNG',maritalStatus:'',education:'',occupation:'',
            sevisPassId:'',village:'',district:'',province:''
        },
        father:{
            available:true,unavailableReason:'',fullName:'',dateOfBirth:'',
            nationality:'PNG',occupation:'',sevisPassId:'',acknowledgmentSigned:false
        },
        witnesses:[],
        evidence:[]
    };
}

/* ===== LOGIN FLOW ===== */
async function initLogin() {
    const area = $('auth-area');
    try {
        const usersRes = await fetch(`${SSO}?action=users`);
        const usersData = await usersRes.json();

        if (usersData.success && usersData.users) {
            APP.bypassUsers = usersData.users;
            APP.bypassMode = true;
            renderBypassLogin();
        } else {
            renderQRLogin();
        }
    } catch (e) {
        area.innerHTML = `<p class="text-red-400 text-sm">Cannot reach SSO server.</p><p class="text-forest-400 text-xs mt-2 font-mono">${e.message}</p>`;
    }
}

function renderBypassLogin() {
    const area = $('auth-area');
    area.innerHTML = `
        <div class="fade-up">
            <div class="p-3 rounded-lg bg-amber-950/30 border border-amber-500/20 text-xs text-amber-300 mb-4 font-mono">
                <i class="fa-solid fa-flask mr-1"></i>
                <strong>SevisPass Bypass Mode</strong> — Direct login without digital wallet. Production uses OIDC4VP QR flow.
            </div>
            <div class="space-y-2 mb-4">
                ${APP.bypassUsers.map(u => `
                    <button onclick="bypassLogin('${u.sub}')" class="w-full p-3 rounded-xl bg-forest-600 border border-forest-500 text-left card-h">
                        <div class="flex items-center gap-3">
                            <div class="w-9 h-9 rounded-lg bg-forest-700 flex items-center justify-center">
                                <i class="fa-solid ${u.role==='field_worker'?'fa-user-nurse':'fa-stamp'} text-gold-400 text-xs"></i>
                            </div>
                            <div class="flex-1 min-w-0">
                                <p class="font-semibold text-sm">${u.name}</p>
                                <p class="text-[11px] text-forest-200 font-mono">${u.role.replace('_',' ')} — T${u.tier} ${TIERS[u.tier]?.short||''} — ${u.facility_name||''}</p>
                            </div>
                            <i class="fa-solid fa-arrow-right text-forest-400 text-xs"></i>
                        </div>
                    </button>
                `).join('')}
            </div>
            <button onclick="renderQRLogin()" class="btn btn-s w-full justify-center text-xs">
                <i class="fa-solid fa-qrcode"></i> Use QR Flow Instead
            </button>
        </div>
    `;
}

async function bypassLogin(userSub) {
    const area = $('auth-area');
    area.innerHTML = `<div class="py-8"><i class="fa-solid fa-spinner spin text-xl text-gold-400"></i><p class="text-forest-200 text-sm mt-3">Authenticating...</p></div>`;

    try {
        const res = await ssoPost('bypass', { user_sub: userSub });
        if (!res.success) throw new Error(res.error);

        APP.sessionId = res.sessionId;
        APP.user = res.user;
        enterApp();
    } catch (e) {
        toast(e.message, 'error');
        renderBypassLogin();
    }
}

function renderQRLogin() {
    const area = $('auth-area');
    area.innerHTML = `
        <div class="fade-up">
            <div id="qr-container" class="hidden">
                <div class="relative inline-block p-4 bg-white rounded-xl mb-4">
                    <div id="qr-display"></div>
                    <div class="scan-line" id="scan-line"></div>
                </div>
                <p id="qr-status" class="text-forest-200 text-sm pulse-slow mb-3">Waiting for SevisPass wallet scan...</p>
                <button id="scan-btn" onclick="simulateScan()" class="btn btn-p btn-sm">
                    <i class="fa-solid fa-mobile-screen"></i> Simulate Wallet Scan
                </button>
            </div>
            <div id="qr-loading" class="py-8">
                <i class="fa-solid fa-spinner spin text-xl text-gold-400"></i>
                <p class="text-forest-200 text-sm mt-3">Generating QR code...</p>
            </div>
            <button onclick="renderBypassLogin()" class="btn btn-s w-full justify-center text-xs mt-4">
                <i class="fa-solid fa-arrow-left"></i> Back to Bypass Login
            </button>
        </div>
    `;
    initQRFlow();
}

async function initQRFlow() {
    try {
        const res = await ssoPost('authorize', { callback_url: window.location.href });
        if (!res.success) throw new Error(res.error);

        APP.sessionId = res.sessionId;
        $('qr-display').innerHTML = res.qrCode;
        $('qr-loading').classList.add('hidden');
        $('qr-container').classList.remove('hidden');

        pollSession();
    } catch (e) {
        toast(e.message, 'error');
    }
}

function pollSession() {
    const poll = async () => {
        try {
            const res = await ssoGet('status');
            if (res.authenticated) {
                $('scan-line').style.display = 'none';
                $('qr-status').textContent = 'Credential verified!';
                $('qr-status').classList.remove('pulse-slow');
                $('scan-btn').disabled = true;

                const userRes = await ssoGet('user');
                if (userRes.success) {
                    APP.user = userRes.user;
                    setTimeout(enterApp, 600);
                }
                return;
            }
            setTimeout(poll, 2000);
        } catch (e) {
            setTimeout(poll, 3000);
        }
    };
    setTimeout(poll, 2000);
}

async function simulateScan() {
    $('scan-btn').disabled = true;
    $('scan-btn').innerHTML = '<i class="fa-solid fa-spinner spin"></i> Scanning...';
    try {
        const userSub = APP.bypassUsers.length > 0 ? APP.bypassUsers[0].sub : null;
        await ssoPost('scan', { session: APP.sessionId, user_sub: userSub });
        $('qr-status').textContent = 'Wallet scanned! Verifying...';
    } catch (e) {
        toast(e.message, 'error');
        $('scan-btn').disabled = false;
        $('scan-btn').innerHTML = '<i class="fa-solid fa-mobile-screen"></i> Simulate Wallet Scan';
    }
}

/* ===== APP ENTRY ===== */
function enterApp() {
    $('login-screen').classList.add('hidden');
    $('app-shell').classList.remove('hidden');
    $('app-shell').classList.add('flex');
    $('u-name').textContent = APP.user.name;
    $('u-role').innerHTML = APP.user.role.replace('_',' ') + ' ' + tB(APP.user.tier);
    $('u-avatar').textContent = APP.user.name.split(' ').map(w=>w[0]).join('');
    $('hdr-date').textContent = new Date().toLocaleDateString('en-GB',{weekday:'short',day:'numeric',month:'short',year:'numeric'});
    const ht = $('hdr-tier');
    ht.className = 'tier-badge tier-' + APP.user.tier;
    ht.textContent = 'T' + APP.user.tier + ' ' + TIERS[APP.user.tier].short;
    buildNav();
    navigate('dashboard');
    toast(`Welcome, ${APP.user.name}`, 'success');
}

async function logout() {
    try { await ssoPost('logout', { session: APP.sessionId }); } catch(e) {}
    APP.user = null; APP.sessionId = null; APP.view = 'dashboard';
    $('app-shell').classList.add('hidden');
    $('app-shell').classList.remove('flex');
    $('login-screen').classList.remove('hidden');
    initLogin();
}

/* ===== NAVIGATION ===== */
const NAV_FW = [
    {id:'dashboard',icon:'fa-chart-line',label:'Dashboard'},
    {id:'new-record',icon:'fa-plus-circle',label:'New Registration'}
];
const NAV_CR = [
    {id:'dashboard',icon:'fa-inbox',label:'Review Queue'},
    {id:'records',icon:'fa-folder-open',label:'All Records'}
];

function buildNav() {
    const items = APP.user.role === 'field_worker' ? NAV_FW : NAV_CR;
    $('nav-list').innerHTML = items.map(n =>
        `<div class="nav-item px-4 py-2.5 flex items-center gap-3 text-sm ${APP.view===n.id?'active':''}" data-nav="${n.id}">
            <i class="fa-solid ${n.icon} w-4 text-center text-xs"></i><span>${n.label}</span>
        </div>`
    ).join('');
    $('nav-list').querySelectorAll('[data-nav]').forEach(el => { el.onclick = () => navigate(el.dataset.nav); });
}

async function navigate(view) {
    APP.view = view;
    const titles = {
        dashboard: APP.user.role==='field_worker'?'Dashboard':'Review Queue',
        'new-record':'New Birth Registration',
        records:'All Records'
    };
    $('page-title').textContent = titles[view] || '';
    buildNav();
    const c = $('content');
    c.innerHTML = '<div class="text-center py-12"><i class="fa-solid fa-spinner spin text-xl text-gold-400"></i><p class="text-forest-200 text-sm mt-3">Loading...</p></div>';

    try {
        if (view === 'dashboard') {
            const data = await apiGet('stats');
            const records = await apiGet('birth-records');
            c.innerHTML = APP.user.role === 'field_worker' ? renderFWDash(data.stats, records.records) : renderCRDash(data.stats, records.records);
        } else if (view === 'new-record') {
            APP.formStep = 0;
            APP.fd = newFd();
            APP.fd.birthEvent.notifierTier = APP.user.tier;
            c.innerHTML = renderForm();
        } else if (view === 'records') {
            const data = await apiGet('birth-records');
            c.innerHTML = renderAllRec(data.records);
        }
    } catch (e) {
        c.innerHTML = `<div class="text-center py-12"><i class="fa-solid fa-triangle-exclamation text-3xl text-red-400 mb-3"></i><p class="text-red-400">${e.message}</p><button class="btn btn-s btn-sm mt-4" onclick="navigate('${view}')">Retry</button></div>`;
        toast(e.message, 'error');
    }
    c.scrollTop = 0;
}

/* ===== DASHBOARD RENDERING ===== */
function sCard(icon,label,val,bg,ic){
    return `<div class="bg-${bg} border border-forest-500 rounded-xl p-4 card-h"><i class="fa-solid ${icon} text-${ic} mb-2"></i><p class="text-2xl font-bold">${val}</p><p class="text-xs text-forest-200 mt-1">${label}</p></div>`;
}

function rRow(r) {
    const n = r.child ? `${r.child.firstName} ${r.child.lastName}` : 'Unknown';
    const bt = BTYPES[r.birthEvent?.type];
    return `<div class="bg-forest-600 border border-forest-500 rounded-xl p-4 flex items-center gap-3 card-h cursor-pointer" onclick="showDetail('${r.id}')">
        <div class="w-9 h-9 rounded-lg bg-forest-700 flex items-center justify-center flex-shrink-0"><i class="fa-solid ${bt?.icon||'fa-baby'} text-gold-400 text-xs"></i></div>
        <div class="flex-1 min-w-0"><p class="font-semibold text-sm truncate">${n}</p><p class="text-[11px] text-forest-200 font-mono">${r.id} · ${bt?.label?.split('—')[0].trim()||''} · ${fmtD(r.child?.dateOfBirth||r.createdAt)}</p></div>
        ${stB(r.state)}<i class="fa-solid fa-chevron-right text-forest-400 text-xs"></i></div>`;
}

function renderFWDash(stats, records) {
    return `<div class="fade-up space-y-5 max-w-4xl">
        <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
            ${sCard('fa-file-pen','Total',stats.total,'forest-500','gold-400')}
            ${sCard('fa-clock','Pending',stats.pending,stats.pending?'amber-900/50':'forest-500',stats.pending?'amber-400':'emerald-400')}
            ${sCard('fa-spinner','In Review',stats.inReview,'forest-500','sky-400')}
            ${sCard('fa-circle-check','Completed',stats.completed,'forest-500','emerald-400')}
        </div>
        <div class="flex items-center justify-between"><h3 class="font-semibold text-sm text-forest-200">Your Records</h3>
        <button class="btn btn-p btn-sm" onclick="navigate('new-record')"><i class="fa-solid fa-plus"></i> New Registration</button></div>
        <div class="space-y-2">${records.length ? records.map(rRow).join('') : '<p class="text-forest-200 text-sm py-8 text-center">No records yet.</p>'}</div></div>`;
}

function renderCRDash(stats, records) {
    const reviewing = records.filter(r=>r.state==='reviewing');
    return `<div class="fade-up space-y-5 max-w-4xl">
        <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
            ${sCard('fa-hourglass-half','Awaiting Review',stats.byState?.reviewing||0,(stats.byState?.reviewing||0)?'amber-900/50':'forest-500',(stats.byState?.reviewing||0)?'amber-400':'emerald-400')}
            ${sCard('fa-check-double','Approved',stats.byState?.approved||0,'forest-500','emerald-400')}
            ${sCard('fa-certificate','Certified',stats.completed,'forest-500','gold-400')}
            ${sCard('fa-rotate-left','Returned',stats.byState?.rejected||0,'forest-500','red-400')}
        </div>
        <h3 class="font-semibold text-sm text-forest-200">Review Queue (${reviewing.length})</h3>
        <div class="space-y-2">${reviewing.length ? reviewing.map(rRow).join('') : '<div class="text-center py-12 text-forest-200"><i class="fa-solid fa-inbox text-3xl mb-3 block text-forest-400"></i><p class="text-sm">No records awaiting review</p></div>'}</div></div>`;
}

function renderAllRec(records) {
    return `<div class="fade-up space-y-4 max-w-4xl"><div class="space-y-2">${records.length ? records.map(rRow).join('') : '<p class="text-forest-200 text-sm py-8 text-center">No records found.</p>'}</div></div>`;
}

/* ===== RECORD DETAIL ===== */
async function showDetail(id) {
    try {
        const data = await apiGet(`birth-records/${id}`);
        const r = data.record;
        const be = r.data.birthEvent;
        const ch = r.data.child;
        const mo = r.data.mother;
        const fa = r.data.father;
        const bt = BTYPES[be.type];

        let html = `
        <div class="space-y-4">
            <div class="flex items-center justify-between">
                <div>
                    <h3 class="text-lg font-bold">${ch.firstName} ${ch.lastName}</h3>
                    <p class="text-xs text-forest-200 font-mono">${r.id} · ${fmtD(be.dateOfBirth)}</p>
                </div>
                ${stB(r.state)}
            </div>

            <div class="grid grid-cols-2 gap-3 text-sm">
                <div class="bg-forest-700/50 rounded-lg p-3">
                    <p class="text-[10px] text-forest-200 uppercase tracking-wider mb-1">Birth Event</p>
                    <p class="font-semibold">${bt?.label||be.type}</p>
                    <p class="text-xs text-forest-200 mt-1">${be.facilityName||be.village||''}, ${be.district||''}, ${be.province||''}</p>
                </div>
                <div class="bg-forest-700/50 rounded-lg p-3">
                    <p class="text-[10px] text-forest-200 uppercase tracking-wider mb-1">Notifier</p>
                    <p class="font-semibold">${r.notification.officerName}</p>
                    <p class="text-xs text-forest-200 mt-1">${r.notification.facilityCode||''}</p>
                </div>
            </div>

            ${r.flags.length ? `<div class="space-y-1">${r.flags.map(f=>`<div class="flex items-start gap-2 text-xs p-2 rounded ${f.sev==='error'?'bg-red-950/50 text-red-300':f.sev==='warn'?'bg-amber-950/50 text-amber-300':'bg-sky-950/50 text-sky-300'}"><i class="fa-solid ${f.icon} mt-0.5"></i><span>${f.msg}</span></div>`).join('')}</div>` : ''}

            <div class="bg-forest-700/30 rounded-lg p-3">
                <p class="text-[10px] text-forest-200 uppercase tracking-wider mb-2">Requirements</p>
                <div class="flex items-center gap-4 text-xs">
                    <span class="${r.requirements.witnesses.met?'req-met':'req-miss'}"><i class="fa-solid ${r.requirements.witnesses.met?'fa-check':'fa-xmark'}"></i> Witnesses</span>
                    <span class="${r.requirements.evidence.met?'req-met':'req-miss'}"><i class="fa-solid ${r.requirements.evidence.met?'fa-check':'fa-xmark'}"></i> Evidence</span>
                    ${r.requirements.timing ? `<span class="${r.requirements.timing.category==='standard'?'req-met':'req-warn'}"><i class="fa-solid fa-clock"></i> ${r.requirements.timing.category}</span>` : ''}
                </div>
            </div>

            ${APP.user.role==='civil_registrar' && r.state==='reviewing' ? `
            <div class="flex gap-2">
                <button onclick="doTransition('${id}','approve')" class="btn btn-ok flex-1 justify-center"><i class="fa-solid fa-check"></i> Approve</button>
                <button onclick="doTransition('${id}','reject')" class="btn btn-d flex-1 justify-center"><i class="fa-solid fa-xmark"></i> Reject</button>
            </div>
            ` : ''}

            ${r.history.length ? `<div class="mt-4"><p class="text-[10px] text-forest-200 uppercase tracking-wider mb-2">History</p><div class="space-y-1">${r.history.map(h=>`<div class="text-xs flex items-center gap-2"><span class="font-mono text-forest-400">${fmtDT(h.created_at)}</span><span>${h.from_state||'—'} → ${h.to_state}</span><span class="text-forest-200">by ${h.actor_name}</span></div>`).join('')}</div></div>` : ''}
        </div>`;

        showModal(html);
    } catch (e) {
        toast(e.message, 'error');
    }
}

async function doTransition(id, action) {
    const pastTense = { approve: 'approved', reject: 'rejected' };
    try {
        await apiPost(`birth-records/${id}/transitions`, { transition: action });
        toast(`Record ${pastTense[action] || action + 'd'} successfully`, 'success');
        closeModal();
        navigate('dashboard');
    } catch (e) {
        toast(e.message, 'error');
    }
}

/* ===== BIRTH REGISTRATION FORM ===== */
function renderForm() {
    const steps = ['Birth Event','Child','Mother','Father','Witnesses','Evidence','Review'];
    const stepDots = steps.map((s,i)=>`
        <div class="flex items-center gap-1">
            <div class="step-dot ${i===APP.formStep?'active':i<APP.formStep?'completed':''}"></div>
            ${i<steps.length-1?`<div class="step-line ${i<APP.formStep?'completed':''}"></div>`:''}
        </div>
        <span class="text-[10px] ${i===APP.formStep?'text-gold-400':'text-forest-400'} ml-1">${s}</span>
    `).join('');

    const reqPanel = renderReqPanel();

    let formContent = '';
    switch(APP.formStep) {
        case 0: formContent = renderStepBirthEvent(); break;
        case 1: formContent = renderStepChild(); break;
        case 2: formContent = renderStepMother(); break;
        case 3: formContent = renderStepFather(); break;
        case 4: formContent = renderStepWitnesses(); break;
        case 5: formContent = renderStepEvidence(); break;
        case 6: formContent = renderStepReview(); break;
    }

    return `<div class="fade-up max-w-5xl mx-auto">
        <div class="flex items-center gap-2 mb-4 overflow-x-auto pb-2">
            ${stepDots}
        </div>
        <div class="form-layout flex gap-6">
            <div class="flex-1 min-w-0">
                <div class="bg-forest-600 border border-forest-500 rounded-xl p-5">
                    ${formContent}
                </div>
                <div class="flex items-center justify-between mt-4">
                    <button onclick="prevStep()" class="btn btn-s btn-sm ${APP.formStep===0?'hidden':''}"><i class="fa-solid fa-arrow-left"></i> Back</button>
                    <div class="flex gap-2">
                        ${APP.formStep < 6 ? `<button onclick="nextStep()" class="btn btn-p btn-sm">Next <i class="fa-solid fa-arrow-right"></i></button>` : ''}
                        ${APP.formStep === 6 ? `<button onclick="submitRecord()" class="btn btn-p"><i class="fa-solid fa-paper-plane"></i> Submit Registration</button>` : ''}
                    </div>
                </div>
            </div>
            <div class="req-panel w-72 flex-shrink-0">
                ${reqPanel}
            </div>
        </div>
    </div>`;
}

function renderReqPanel() {
    const be = APP.fd.birthEvent;
    const timing = calcTiming(be.dateOfBirth);
    const wr = getWitnessReqs(be.type, be.notifierTier);
    const er = getEvidenceReqs(be.type, timing?.category);
    const wm = checkWitnessesMet(wr, APP.fd.witnesses);
    const em = checkEvidenceMet(er, APP.fd.evidence);
    const flags = calcFlags(APP.fd);

    return `<div class="bg-forest-600 border border-forest-500 rounded-xl p-4 sticky top-0">
        <h4 class="text-sm font-bold mb-3 flex items-center gap-2"><i class="fa-solid fa-clipboard-check text-gold-400"></i> Requirements</h4>

        <div class="space-y-3 text-xs">
            <div>
                <p class="text-forest-200 mb-1">Witnesses</p>
                <div class="flex items-center gap-2 ${wm.met?'req-met':'req-miss'}">
                    <i class="fa-solid ${wm.met?'fa-check':'fa-xmark'}"></i>
                    <span>${wm.met?'Met':wm.gap>0?`${wm.gap} missing`:'Tier issue'}</span>
                </div>
                ${wr.reasons.length ? `<p class="text-forest-400 mt-1 text-[10px]">${wr.reasons[0]}</p>` : ''}
            </div>

            <div>
                <p class="text-forest-200 mb-1">Evidence</p>
                <div class="flex items-center gap-2 ${em.met?'req-met':'req-miss'}">
                    <i class="fa-solid ${em.met?'fa-check':'fa-xmark'}"></i>
                    <span>${em.met?'Complete':`${em.missing.length} missing`}</span>
                </div>
            </div>

            ${timing ? `<div>
                <p class="text-forest-200 mb-1">Timing</p>
                <span class="${timing.category==='standard'?'text-emerald-400':timing.category==='late'?'text-amber-400':'text-red-400'}">
                    ${timing.category==='standard'?'Standard':timing.category==='late'?'Late (fee)':'Very late (inquiry)'}
                </span>
                <span class="text-forest-400 ml-1">${timing.days} days</span>
            </div>` : ''}
        </div>

        ${flags.length ? `<div class="mt-4 pt-3 border-t border-forest-500">
            <p class="text-[10px] text-forest-200 uppercase tracking-wider mb-2">Flags</p>
            <div class="space-y-1">${flags.map(f=>`<div class="flex items-start gap-1.5 text-[10px] ${f.sev==='error'?'text-red-400':f.sev==='warn'?'text-amber-400':'text-sky-400'}"><i class="fa-solid ${f.icon} mt-0.5"></i><span>${f.msg}</span></div>`).join('')}</div>
        </div>` : ''}
    </div>`;
}

function renderStepBirthEvent() {
    const be = APP.fd.birthEvent;
    return `
        <h3 class="text-lg font-bold mb-4">Birth Event Details</h3>
        <div class="space-y-4">
            <div>
                <label class="text-xs text-forest-200 block mb-1">Birth Type</label>
                <select onchange="updateFd('birthEvent.type',this.value);updateForm()">
                    <option value="">Select birth type...</option>
                    ${Object.entries(BTYPES).map(([k,v])=>`<option value="${k}" ${be.type===k?'selected':''}>${v.label}</option>`).join('')}
                </select>
            </div>
            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="text-xs text-forest-200 block mb-1">Date of Birth</label>
                    <input type="date" value="${be.dateOfBirth}" onchange="updateFd('birthEvent.dateOfBirth',this.value);updateForm()">
                </div>
                <div>
                    <label class="text-xs text-forest-200 block mb-1">Time of Birth</label>
                    <input type="time" value="${be.timeOfBirth}" onchange="updateFd('birthEvent.timeOfBirth',this.value)">
                </div>
            </div>
            <div class="flex items-center gap-2">
                <input type="checkbox" id="mult-birth" ${be.isMultipleBirth?'checked':''} onchange="updateFd('birthEvent.isMultipleBirth',this.checked);updateForm()">
                <label for="mult-birth" class="text-xs">Multiple birth</label>
            </div>
            ${be.isMultipleBirth ? `<div class="grid grid-cols-2 gap-3">
                <div><label class="text-xs text-forest-200 block mb-1">Birth Order</label><input type="number" min="1" value="${be.multipleBirthOrder||1}" onchange="updateFd('birthEvent.multipleBirthOrder',parseInt(this.value))"></div>
                <div><label class="text-xs text-forest-200 block mb-1">Total Births</label><input type="number" min="2" value="${be.multipleBirthTotal||2}" onchange="updateFd('birthEvent.multipleBirthTotal',parseInt(this.value))"></div>
            </div>` : ''}
            <div class="flex items-center gap-2">
                <input type="checkbox" id="mom-surv" ${be.motherSurvived!==false?'checked':''} onchange="updateFd('birthEvent.motherSurvived',this.checked);updateForm()">
                <label for="mom-surv" class="text-xs">Mother survived</label>
            </div>
            ${BTYPES[be.type]?.reqFac ? `
            <div>
                <label class="text-xs text-forest-200 block mb-1">Facility Name</label>
                <input type="text" value="${be.facilityName}" placeholder="e.g. Goroka Health Center" onchange="updateFd('birthEvent.facilityName',this.value)">
            </div>
            <div>
                <label class="text-xs text-forest-200 block mb-1">Facility Code</label>
                <input type="text" value="${be.facilityCode}" placeholder="e.g. HC-EHG-012" onchange="updateFd('birthEvent.facilityCode',this.value)">
            </div>
            ` : `
            <div>
                <label class="text-xs text-forest-200 block mb-1">Village</label>
                <input type="text" value="${be.village}" placeholder="Village name" onchange="updateFd('birthEvent.village',this.value)">
            </div>
            `}
            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="text-xs text-forest-200 block mb-1">District</label>
                    <input type="text" value="${be.district}" placeholder="District" onchange="updateFd('birthEvent.district',this.value)">
                </div>
                <div>
                    <label class="text-xs text-forest-200 block mb-1">Province</label>
                    <select onchange="updateFd('birthEvent.province',this.value)">
                        <option value="">Select province...</option>
                        ${PROVINCES.map(p=>`<option value="${p}" ${be.province===p?'selected':''}>${p}</option>`).join('')}
                    </select>
                </div>
            </div>
        </div>
    `;
}

function renderStepChild() {
    const ch = APP.fd.child;
    return `
        <h3 class="text-lg font-bold mb-4">Child Information</h3>
        <div class="space-y-4">
            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="text-xs text-forest-200 block mb-1">First Name</label>
                    <input type="text" value="${ch.firstName}" placeholder="First name" onchange="updateFd('child.firstName',this.value);updateForm()">
                </div>
                <div>
                    <label class="text-xs text-forest-200 block mb-1">Last Name</label>
                    <input type="text" value="${ch.lastName}" placeholder="Last name" onchange="updateFd('child.lastName',this.value);updateForm()">
                </div>
            </div>
            <div>
                <label class="text-xs text-forest-200 block mb-1">Sex</label>
                <div class="flex gap-3">
                    ${['male','female','intersex'].map(s=>`
                        <label class="flex items-center gap-2 cursor-pointer">
                            <input type="radio" name="child-sex" value="${s}" ${ch.sex===s?'checked':''} onchange="updateFd('child.sex',this.value);updateForm()">
                            <span class="text-sm capitalize">${s}</span>
                        </label>
                    `).join('')}
                </div>
            </div>
            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="text-xs text-forest-200 block mb-1">Birth Weight (kg)</label>
                    <input type="number" step="0.01" value="${ch.birthWeight||''}" placeholder="e.g. 3.2" onchange="updateFd('child.birthWeight',parseFloat(this.value)||null);updateForm()">
                </div>
                <div>
                    <label class="text-xs text-forest-200 block mb-1">Birth Length (cm)</label>
                    <input type="number" step="0.1" value="${ch.birthLength||''}" placeholder="e.g. 50.0" onchange="updateFd('child.birthLength',parseFloat(this.value)||null)">
                </div>
            </div>
            <div>
                <label class="text-xs text-forest-200 block mb-1">Congenital Anomalies (if any)</label>
                <textarea rows="2" placeholder="Describe any anomalies..." onchange="updateFd('child.congenitalAnomalies',this.value)">${ch.congenitalAnomalies}</textarea>
            </div>
        </div>
    `;
}

function renderStepMother() {
    const mo = APP.fd.mother;
    return `
        <h3 class="text-lg font-bold mb-4">Mother Information</h3>
        <div class="space-y-4">
            <div>
                <label class="text-xs text-forest-200 block mb-1">Full Name</label>
                <input type="text" value="${mo.fullName}" placeholder="Mother's full name" onchange="updateFd('mother.fullName',this.value);updateForm()">
            </div>
            <div class="flex items-center gap-2 mb-2">
                <input type="checkbox" id="est-age" ${mo.useEstimatedAge?'checked':''} onchange="updateFd('mother.useEstimatedAge',this.checked);updateForm()">
                <label for="est-age" class="text-xs">Use estimated age (no exact DOB)</label>
            </div>
            ${mo.useEstimatedAge ? `
            <div>
                <label class="text-xs text-forest-200 block mb-1">Estimated Age (years)</label>
                <input type="number" min="10" max="80" value="${mo.estimatedAge||''}" onchange="updateFd('mother.estimatedAge',parseInt(this.value));updateForm()">
            </div>
            ` : `
            <div>
                <label class="text-xs text-forest-200 block mb-1">Date of Birth</label>
                <input type="date" value="${mo.dateOfBirth}" onchange="updateFd('mother.dateOfBirth',this.value);updateForm()">
            </div>
            `}
            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="text-xs text-forest-200 block mb-1">Nationality</label>
                    <input type="text" value="${mo.nationality}" onchange="updateFd('mother.nationality',this.value);updateForm()">
                </div>
                <div>
                    <label class="text-xs text-forest-200 block mb-1">Marital Status</label>
                    <select onchange="updateFd('mother.maritalStatus',this.value);updateForm()">
                        <option value="">Select...</option>
                        ${['single','married','divorced','widowed'].map(s=>`<option value="${s}" ${mo.maritalStatus===s?'selected':''}>${s.charAt(0).toUpperCase()+s.slice(1)}</option>`).join('')}
                    </select>
                </div>
            </div>
            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="text-xs text-forest-200 block mb-1">Education</label>
                    <select onchange="updateFd('mother.education',this.value)">
                        <option value="">Select...</option>
                        ${['none','primary','secondary','tertiary'].map(s=>`<option value="${s}" ${mo.education===s?'selected':''}>${s.charAt(0).toUpperCase()+s.slice(1)}</option>`).join('')}
                    </select>
                </div>
                <div>
                    <label class="text-xs text-forest-200 block mb-1">Occupation</label>
                    <input type="text" value="${mo.occupation}" placeholder="Occupation" onchange="updateFd('mother.occupation',this.value)">
                </div>
            </div>
            <div>
                <label class="text-xs text-forest-200 block mb-1">SevisPass ID (if available)</label>
                <input type="text" value="${mo.sevisPassId}" placeholder="e.g. SP-001-2024" onchange="updateFd('mother.sevisPassId',this.value)">
            </div>
        </div>
    `;
}

function renderStepFather() {
    const fa = APP.fd.father;
    return `
        <h3 class="text-lg font-bold mb-4">Father Information</h3>
        <div class="space-y-4">
            <div class="flex items-center gap-2">
                <input type="checkbox" id="fa-avail" ${fa.available?'checked':''} onchange="updateFd('father.available',this.checked);updateForm()">
                <label for="fa-avail" class="text-xs">Father details available</label>
            </div>
            ${fa.available ? `
            <div class="space-y-4">
                <div>
                    <label class="text-xs text-forest-200 block mb-1">Full Name</label>
                    <input type="text" value="${fa.fullName}" placeholder="Father's full name" onchange="updateFd('father.fullName',this.value);updateForm()">
                </div>
                <div>
                    <label class="text-xs text-forest-200 block mb-1">Date of Birth</label>
                    <input type="date" value="${fa.dateOfBirth}" onchange="updateFd('father.dateOfBirth',this.value);updateForm()">
                </div>
                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="text-xs text-forest-200 block mb-1">Nationality</label>
                        <input type="text" value="${fa.nationality}" onchange="updateFd('father.nationality',this.value)">
                    </div>
                    <div>
                        <label class="text-xs text-forest-200 block mb-1">Occupation</label>
                        <input type="text" value="${fa.occupation}" placeholder="Occupation" onchange="updateFd('father.occupation',this.value)">
                    </div>
                </div>
                <div>
                    <label class="text-xs text-forest-200 block mb-1">SevisPass ID</label>
                    <input type="text" value="${fa.sevisPassId}" placeholder="e.g. SP-002-2024" onchange="updateFd('father.sevisPassId',this.value)">
                </div>
                ${APP.fd.mother?.maritalStatus==='single' ? `
                <div class="flex items-center gap-2 p-3 bg-amber-950/20 rounded-lg border border-amber-500/20">
                    <input type="checkbox" id="paternity-sign" ${fa.acknowledgmentSigned?'checked':''} onchange="updateFd('father.acknowledgmentSigned',this.checked);updateForm()">
                    <label for="paternity-sign" class="text-xs text-amber-300">Paternity acknowledgment signed</label>
                </div>
                ` : ''}
            </div>
            ` : `
            <div>
                <label class="text-xs text-forest-200 block mb-1">Reason Unavailable</label>
                <select onchange="updateFd('father.unavailableReason',this.value);updateForm()">
                    <option value="">Select reason...</option>
                    ${['unknown','deceased','abandoned','refused','other'].map(r=>`<option value="${r}" ${fa.unavailableReason===r?'selected':''}>${r.charAt(0).toUpperCase()+r.slice(1)}</option>`).join('')}
                </select>
            </div>
            `}
        </div>
    `;
}

function renderStepWitnesses() {
    const wr = getWitnessReqs(APP.fd.birthEvent.type, APP.fd.birthEvent.notifierTier);
    const witnesses = APP.fd.witnesses;

    return `
        <h3 class="text-lg font-bold mb-4">Witnesses</h3>
        <div class="space-y-3">
            <div class="p-3 bg-forest-700/30 rounded-lg text-xs">
                <p class="font-semibold mb-1">Required: ${wr.count} witness(es)</p>
                ${wr.minTier !== null ? `<p class="text-forest-200">Minimum tier: T${wr.minTier} ${TIERS[wr.minTier]?.short||''}</p>` : ''}
                ${wr.reasons.length ? `<p class="text-forest-400 mt-1">${wr.reasons[0]}</p>` : ''}
            </div>
            ${witnesses.map((w,i)=>`
                <div class="witness-card">
                    <div class="flex items-center justify-between mb-2">
                        <span class="text-xs font-bold">Witness ${i+1}</span>
                        <button onclick="removeWitness(${i})" class="text-red-400 text-xs hover:text-red-300"><i class="fa-solid fa-trash"></i></button>
                    </div>
                    <div class="space-y-2">
                        <input type="text" value="${w.fullName||''}" placeholder="Full name" onchange="updateWitness(${i},'fullName',this.value);updateForm()">
                        <div class="grid grid-cols-2 gap-2">
                            <select onchange="updateWitness(${i},'tier',parseInt(this.value));updateForm()">
                                <option value="">Tier...</option>
                                ${[0,1,2,3,4].map(t=>`<option value="${t}" ${w.tier===t?'selected':''}>T${t} ${TIERS[t]?.short||''}</option>`).join('')}
                            </select>
                            <input type="text" value="${w.sevispassId||''}" placeholder="SevisPass ID" onchange="updateWitness(${i},'sevispassId',this.value)">
                        </div>
                        <input type="text" value="${w.idType||''}" placeholder="ID Type (NID/Passport/Driver's)" onchange="updateWitness(${i},'idType',this.value)">
                        <input type="text" value="${w.idNumber||''}" placeholder="ID Number" onchange="updateWitness(${i},'idNumber',this.value)">
                        <input type="text" value="${w.village||''}" placeholder="Village" onchange="updateWitness(${i},'village',this.value)">
                    </div>
                </div>
            `).join('')}
            ${witnesses.length < 5 ? `
            <button onclick="addWitness()" class="btn btn-s w-full justify-center text-xs">
                <i class="fa-solid fa-plus"></i> Add Witness
            </button>
            ` : ''}
        </div>
    `;
}

function renderStepEvidence() {
    const be = APP.fd.birthEvent;
    const timing = calcTiming(be.dateOfBirth);
    const er = getEvidenceReqs(be.type, timing?.category);
    const ev = APP.fd.evidence;

    const isAttached = (key) => ev.some(e=>e.type===key && e.attached);

    return `
        <h3 class="text-lg font-bold mb-4">Evidence & Documents</h3>
        <div class="space-y-3">
            <div>
                <p class="text-xs font-semibold text-forest-200 mb-2">Required Documents</p>
                <div class="space-y-1">
                    ${er.required.map(r=>`
                        <div class="evidence-item ${isAttached(r.key)?'attached':''} required" onclick="toggleEvidence('${r.key}');updateForm()">
                            <i class="fa-solid ${isAttached(r.key)?'fa-check-circle text-emerald-400':'fa-circle text-forest-400'}"></i>
                            <span class="text-xs flex-1">${r.label}</span>
                            <span class="text-[10px] ${isAttached(r.key)?'text-emerald-400':'text-red-400'}">${isAttached(r.key)?'Attached':'Required'}</span>
                        </div>
                    `).join('')}
                </div>
            </div>
            <div>
                <p class="text-xs font-semibold text-forest-200 mb-2">Recommended Documents</p>
                <div class="space-y-1">
                    ${er.recommended.map(r=>`
                        <div class="evidence-item ${isAttached(r.key)?'attached':''}" onclick="toggleEvidence('${r.key}');updateForm()">
                            <i class="fa-solid ${isAttached(r.key)?'fa-check-circle text-emerald-400':'fa-circle text-forest-400'}"></i>
                            <span class="text-xs flex-1">${r.label}</span>
                            <span class="text-[10px] ${isAttached(r.key)?'text-emerald-400':'text-forest-400'}">${isAttached(r.key)?'Attached':'Optional'}</span>
                        </div>
                    `).join('')}
                </div>
            </div>
        </div>
    `;
}

function renderStepReview() {
    const v = validateForSubmit(APP.fd);
    const be = APP.fd.birthEvent;
    const ch = APP.fd.child;
    const mo = APP.fd.mother;
    const fa = APP.fd.father;

    return `
        <h3 class="text-lg font-bold mb-4">Review & Submit</h3>
        <div class="space-y-4">
            ${!v.valid ? `<div class="p-3 bg-red-950/30 border border-red-500/20 rounded-lg">
                <p class="text-xs font-bold text-red-400 mb-1"><i class="fa-solid fa-triangle-exclamation"></i> Validation Errors</p>
                <ul class="text-xs text-red-300 space-y-0.5">${v.errors.map(e=>`<li>• ${e}</li>`).join('')}</ul>
            </div>` : `<div class="p-3 bg-emerald-950/30 border border-emerald-500/20 rounded-lg">
                <p class="text-xs font-bold text-emerald-400"><i class="fa-solid fa-circle-check"></i> All requirements met</p>
            </div>`}

            ${v.warnings.length ? `<div class="p-3 bg-amber-950/20 border border-amber-500/20 rounded-lg">
                <p class="text-xs font-bold text-amber-400 mb-1">Warnings</p>
                <ul class="text-xs text-amber-300 space-y-0.5">${v.warnings.map(w=>`<li>• ${w}</li>`).join('')}</ul>
            </div>` : ''}

            <div class="bg-forest-700/30 rounded-lg p-3 text-xs space-y-2">
                <p class="font-bold text-forest-200">Summary</p>
                <div class="grid grid-cols-2 gap-2">
                    <div><span class="text-forest-400">Child:</span> ${ch.firstName} ${ch.lastName}</div>
                    <div><span class="text-forest-400">DOB:</span> ${be.dateOfBirth}</div>
                    <div><span class="text-forest-400">Mother:</span> ${mo.fullName}</div>
                    <div><span class="text-forest-400">Type:</span> ${BTYPES[be.type]?.label||be.type}</div>
                </div>
            </div>
        </div>
    `;
}

/* ===== FORM HELPERS ===== */
function updateFd(path, value) {
    const parts = path.split('.');
    let target = APP.fd;
    for (let i = 0; i < parts.length - 1; i++) {
        target = target[parts[i]];
    }
    target[parts[parts.length - 1]] = value;

    // Auto-set requiresFacility
    if (path === 'birthEvent.type') {
        APP.fd.birthEvent.requiresFacility = BTYPES[value]?.reqFac || false;
    }
}

function updateForm() {
    $('content').innerHTML = renderForm();
}

function nextStep() {
    if (APP.formStep < 6) {
        APP.formStep++;
        updateForm();
    }
}

function prevStep() {
    if (APP.formStep > 0) {
        APP.formStep--;
        updateForm();
    }
}

function addWitness() {
    APP.fd.witnesses.push({fullName:'',tier:0,sevispassId:'',idType:'',idNumber:'',village:''});
    updateForm();
}

function removeWitness(idx) {
    APP.fd.witnesses.splice(idx, 1);
    updateForm();
}

function updateWitness(idx, field, value) {
    APP.fd.witnesses[idx][field] = value;
}

function toggleEvidence(key) {
    const idx = APP.fd.evidence.findIndex(e=>e.type===key);
    if (idx >= 0) {
        APP.fd.evidence.splice(idx, 1);
    } else {
        APP.fd.evidence.push({type:key, attached:true, notes:''});
    }
}

async function submitRecord() {
    const v = validateForSubmit(APP.fd);
    if (!v.valid) {
        toast('Please fix validation errors before submitting', 'error');
        return;
    }

    try {
        const res = await apiPost('birth-records', APP.fd);
        toast(`Registration submitted: ${res.id}`, 'success');
        navigate('dashboard');
    } catch (e) {
        toast(e.message, 'error');
    }
}

/* ===== INIT ===== */
document.addEventListener('DOMContentLoaded', initLogin);
