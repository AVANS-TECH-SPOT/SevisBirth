<?php
/* ============================================================
   FILE: database.php
   SQLite PDO Connection + Schema Management
   ============================================================ */

require_once __DIR__ . '/config.php';

class Database {
    private static ?PDO $pdo = null;

    public static function getInstance(): PDO {
        if (self::$pdo === null) {
            if (!is_dir(DB_DIR)) {
                mkdir(DB_DIR, 0755, true);
            }
            self::$pdo = new PDO('sqlite:' . DB_PATH);
            self::$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            self::$pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
            self::$pdo->exec('PRAGMA journal_mode=WAL');
            self::$pdo->exec('PRAGMA foreign_keys=ON');
        }
        return self::$pdo;
    }

    public static function initSchema(): void {
        $db = self::getInstance();

        // Mock users (SevisPass identity holders)
        $db->exec("CREATE TABLE IF NOT EXISTS mock_users (
            sub TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            email TEXT DEFAULT '',
            role TEXT NOT NULL,       -- field_worker | civil_registrar | registrar_general
            tier INTEGER NOT NULL DEFAULT 0,  -- 0=VHV, 1=CHW, 2=NO, 3=MO, 4=SP
            facility_code TEXT DEFAULT '',
            facility_name TEXT DEFAULT '',
            sevispass_id TEXT DEFAULT '',
            password TEXT NOT NULL DEFAULT ''
        )");

        // SSO sessions
        $db->exec("CREATE TABLE IF NOT EXISTS sso_sessions (
            id TEXT PRIMARY KEY,
            state TEXT NOT NULL,
            nonce TEXT NOT NULL,
            callback_url TEXT DEFAULT '',
            vp_token TEXT DEFAULT '',
            user_sub TEXT DEFAULT '',
            authenticated INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL,
            expires_at TEXT NOT NULL
        )");

        // Birth records
        $db->exec("CREATE TABLE IF NOT EXISTS birth_records (
            id TEXT PRIMARY KEY,
            state TEXT NOT NULL DEFAULT 'draft',
            birth_event TEXT NOT NULL DEFAULT '{}',
            child_data TEXT NOT NULL DEFAULT '{}',
            mother_data TEXT NOT NULL DEFAULT '{}',
            father_data TEXT NOT NULL DEFAULT '{}',
            witnesses_data TEXT NOT NULL DEFAULT '[]',
            evidence_data TEXT NOT NULL DEFAULT '[]',
            encrypted_blob TEXT DEFAULT NULL,
            encryption_meta TEXT DEFAULT NULL,
            plaintext_hash TEXT DEFAULT NULL,
            operator_did TEXT DEFAULT '',
            operator_name TEXT DEFAULT '',
            operator_role TEXT DEFAULT '',
            facility_code TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            version INTEGER NOT NULL DEFAULT 1
        )");

        // State history (audit trail)
        $db->exec("CREATE TABLE IF NOT EXISTS state_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            record_id TEXT NOT NULL,
            from_state TEXT DEFAULT NULL,
            to_state TEXT NOT NULL,
            actor_name TEXT NOT NULL,
            actor_role TEXT NOT NULL,
            reason TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            FOREIGN KEY (record_id) REFERENCES birth_records(id) ON DELETE CASCADE
        )");

        $db->exec("CREATE INDEX IF NOT EXISTS idx_records_state ON birth_records(state)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_records_operator ON birth_records(operator_name)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_records_created ON birth_records(created_at)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_history_record ON state_history(record_id)");
    }

    public static function seedMockUsers(): void {
        $db = self::getInstance();
        $users = [
            ['did:sp:maria-001', 'Maria Kila', 'maria@health.gov.pg', 'field_worker', 2, 'HC-EHG-012', 'Goroka Health Center', 'SP-001-2024', ''],
            ['did:sp:peter-003', 'Peter Yawi', 'peter@health.gov.pg', 'field_worker', 1, 'AP-ESW-003', 'Asaro Aid Post', 'SP-003-2024', ''],
            ['did:sp:lina-004', 'Lina Kora', '', 'field_worker', 0, 'VHV-ESW-007', 'Kundiawa Village', 'SP-004-2024', ''],
            ['did:sp:john-002', 'John Tau', 'john.tau@justice.gov.pg', 'civil_registrar', 3, 'DR-EHG-001', 'Eastern Highlands District Registry', 'SP-002-2024', ''],
            ['did:sp:regina-005', 'Regina Poka', 'regina@justice.gov.pg', 'registrar_general', 4, 'NCR-POM-001', 'National Civil Registry', 'SP-005-2024', ''],
        ];

        $stmt = $db->prepare("INSERT OR IGNORE INTO mock_users (sub, name, email, role, tier, facility_code, facility_name, sevispass_id, password) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        foreach ($users as $u) {
            $stmt->execute($u);
        }
    }

    /**
     * Encrypt data with AES-256-GCM using PBKDF2 key derivation.
     */
    public static function encrypt(array $data): array {
        $salt = openssl_random_pseudo_bytes(16);
        $iv = openssl_random_pseudo_bytes(12);
        $key = hash_pbkdf2('sha256', ENCRYPTION_PASSPHRASE, $salt, PBKDF2_ITERATIONS, 32, true);
        $plaintext = json_encode($data, JSON_UNESCAPED_UNICODE);
        $tag = '';
        $ciphertext = openssl_encrypt($plaintext, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag);

        if ($ciphertext === false) {
            throw new RuntimeException('Encryption failed: ' . openssl_error_string());
        }

        return [
            'ciphertext' => base64_encode($ciphertext),
            'salt' => base64_encode($salt),
            'iv' => base64_encode($iv),
            'tag' => base64_encode($tag),
            'algorithm' => 'AES-256-GCM',
            'keyDerivation' => 'PBKDF2',
            'iterations' => PBKDF2_ITERATIONS
        ];
    }

    public static function decrypt(array $meta, string $ciphertextB64): ?array {
        $salt = base64_decode($meta['salt']);
        $iv = base64_decode($meta['iv']);
        $tag = base64_decode($meta['tag']);
        $ciphertext = base64_decode($ciphertextB64);
        $key = hash_pbkdf2('sha256', ENCRYPTION_PASSPHRASE, $salt, PBKDF2_ITERATIONS, 32, true);
        $plaintext = openssl_decrypt($ciphertext, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag);
        return $plaintext !== false ? json_decode($plaintext, true) : null;
    }

    public static function hashData(array $data): string {
        $sorted = self::ksortRecursive($data);
        return hash('sha256', json_encode($sorted, JSON_UNESCAPED_UNICODE));
    }

    /**
     * Recursively sort array keys so hashData() produces a stable hash
     * regardless of key insertion order (PHP's json_encode has no
     * built-in "sort keys" flag, so this is done manually).
     */
    private static function ksortRecursive(array $data): array {
        foreach ($data as &$value) {
            if (is_array($value)) {
                $value = self::ksortRecursive($value);
            }
        }
        unset($value);
        ksort($data);
        return $data;
    }
}
